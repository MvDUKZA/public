<#
.SYNOPSIS
    Generates native Packer HCL2 build files from SCCM metadata.

.DESCRIPTION
    Implements "Packer and SCCM - Final Design v2".

    SCCM is the single source of truth. This script:
      1. Reads metadata lines from SCCM Deployment Types, Package Programs
         and Scripts via the AdminService REST API (Windows pass-through auth).
      2. Parses each pipe-delimited line:
             <Target>|<Ring>|<Order>|<Reboot>|<Pause>[|<OverrideValue>]
      3. Validates fail-fast (token count, numeric Order, controlled
         Reboot/Pause values, duplicate overrides, ambiguous candidates).
      4. Filters to the requested build Target (specific target + PX,
         with specific-beats-PX precedence per SCCM execution unit).
      5. Applies named override selection when -OverrideValue is supplied.
      6. Sorts by Ring (config-defined order), then numeric Order.
      7. Emits one build.<ring>.pkr.hcl per ring, each step fully
         commented with its SCCM source details, plus per-item install
         wrapper scripts and a shared vars file.

    Reboots are emitted as native windows-restart provisioner steps.
    Pause-before uses the native pause_before attribute; pause-after is
    an explicit generated sleep step (Packer has no native pause-after).

.PARAMETER OSFolder
    Name of the serviced OS folder in the OS library, e.g.
    Win11_Enterprise_24H2_0625. Drives ISO path and artifact naming.

.PARAMETER Target
    Build target token, e.g. PV (VDI), PS (Server), PD (Desktop), PL (Laptop).
    PX-tagged items are always included unless beaten by a specific line.

.PARAMETER OverrideValue
    Optional engineer/test override, e.g. 'Marinus'. When supplied, a
    6-token line whose OverrideValue matches replaces the default line
    for that SCCM execution unit.

.PARAMETER DryRun
    Resolve and print the sorted item list; write no files.

.PARAMETER OutputPath
    Root output folder. Default: .\output

.EXAMPLE
    .\Invoke-GoldsmithGenerator.ps1 -OSFolder Win11_Enterprise_24H2_0625 -Target PV -DryRun

.EXAMPLE
    .\Invoke-GoldsmithGenerator.ps1 -OSFolder Win11_Enterprise_24H2_0625 -Target PV -OverrideValue Marinus
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$OSFolder,

    [Parameter(Mandatory)]
    [string]$Target,

    [string]$OverrideValue,

    # Named vCenter from config VCenters. Omit to use DefaultVCenter.
    [string]$VCenter,

    [switch]$DryRun,

    [string]$OutputPath,

    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config\build-config.psd1')
)

#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ══════════════════════════════════════════════════════════════════════
#  Constants (controlled values — design doc §5.4 / §5.5)
# ══════════════════════════════════════════════════════════════════════
$Script:ValidReboot   = @('NR', 'RB', 'RA')
$Script:ValidPause    = @('NP', 'PB', 'PA')
$Script:CrossPlatform = 'PX'

# ══════════════════════════════════════════════════════════════════════
#  Configuration
# ══════════════════════════════════════════════════════════════════════
function Get-BuildConfig {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        throw "Config file not found: $Path"
    }
    Import-PowerShellDataFile -Path $Path
}

# ══════════════════════════════════════════════════════════════════════
#  AdminService client
# ══════════════════════════════════════════════════════════════════════
function Invoke-AdminService {
    <#  Thin wrapper over the ConfigMgr AdminService REST API.
        Uses Windows pass-through auth on the domain-joined jump box.

        NOTE: do NOT add $select for LAZY properties (e.g. SDMPackageXML).
        The AdminService cannot run a targeted query for a lazy property
        and returns 404 "Error waiting for query to return." Fetch the
        full instance instead and read the property off the result.       #>
    param(
        [Parameter(Mandatory)][hashtable]$Config,
        [Parameter(Mandatory)][string]$Query          # e.g. wmi/SMS_Package?$select=...
    )
    $uri = '{0}/{1}' -f $Config.AdminService.BaseUrl.TrimEnd('/'), $Query
    Write-Verbose "AdminService GET $uri"
    $params = @{ Method = 'Get'; Uri = $uri }
    if ($Config.AdminService.UseDefaultCredentials) {
        $params['UseDefaultCredentials'] = $true
    }
    $response = Invoke-RestMethod @params
    if ($null -ne $response.PSObject.Properties['value']) { return $response.value }
    return $response
}

# ══════════════════════════════════════════════════════════════════════
#  Metadata parsing + validation  (design doc §4, §5, §12)
# ══════════════════════════════════════════════════════════════════════
function ConvertFrom-MetadataLine {
    <#  Parses ONE pipe-delimited metadata line. Throws with a precise,
        item-identifying message on any violation (fail fast, §12).     #>
    param(
        [Parameter(Mandatory)][string]$Line,
        [Parameter(Mandatory)][string]$ItemIdentity   # for error messages
    )
    $tokens = $Line.Split('|') | ForEach-Object { $_.Trim() }

    if ($tokens.Count -lt 5 -or $tokens.Count -gt 6) {
        throw "VALIDATION [$ItemIdentity] token count is $($tokens.Count), must be 5 or 6. Line: '$Line'"
    }

    $order = 0
    if (-not [int]::TryParse($tokens[2], [ref]$order)) {
        throw "VALIDATION [$ItemIdentity] Order '$($tokens[2])' is not numeric. Line: '$Line'"
    }
    if ($tokens[3] -notin $Script:ValidReboot) {
        throw "VALIDATION [$ItemIdentity] Reboot '$($tokens[3])' not one of NR, RB, RA. Line: '$Line'"
    }
    if ($tokens[4] -notin $Script:ValidPause) {
        throw "VALIDATION [$ItemIdentity] Pause '$($tokens[4])' not one of NP, PB, PA. Line: '$Line'"
    }

    [pscustomobject]@{
        Target        = $tokens[0].ToUpper()
        Ring          = $tokens[1].ToUpper()
        Order         = $order
        Reboot        = $tokens[3].ToUpper()
        Pause         = $tokens[4].ToUpper()
        OverrideValue = if ($tokens.Count -eq 6) { $tokens[5] } else { $null }
        Raw           = $Line
    }
}

function Get-MetadataLinesFromField {
    <#  A single SCCM field may hold multiple metadata lines (§14.2).
        Non-metadata text is ignored: only lines with 4+ pipe chars are
        treated as candidate metadata; everything else is skipped.      #>
    param([string]$FieldText)
    if ([string]::IsNullOrWhiteSpace($FieldText)) { return @() }
    $FieldText -split "`r?`n" |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and (@($_.ToCharArray() | Where-Object { $_ -eq '|' }).Count -ge 4) }
}

# ══════════════════════════════════════════════════════════════════════
#  SCCM collectors — Applications, Packages, Scripts
#  Each returns items shaped as:
#    SourceType, Identity, DisplayLines (hashtable of comment fields),
#    MetadataLines, Execution (how to actually install the thing)
# ══════════════════════════════════════════════════════════════════════
function Get-TaggedPackagePrograms {
    param([hashtable]$Config)
    Write-Host '  Scanning SCCM Package Programs...' -ForegroundColor DarkGray

    $field    = $Config.MetadataFields.PackageProgram
    $packages = Invoke-AdminService -Config $Config -Query 'wmi/SMS_Package?$select=PackageID,Name,PkgSourcePath'
    $pkgIndex = @{}
    foreach ($p in $packages) { $pkgIndex[$p.PackageID] = $p }

    $programs = Invoke-AdminService -Config $Config -Query "wmi/SMS_Program?`$select=PackageID,ProgramName,CommandLine,$field"

    foreach ($prog in $programs) {
        $lines = Get-MetadataLinesFromField -FieldText $prog.$field
        if (-not $lines) { continue }
        $pkg = $pkgIndex[$prog.PackageID]
        if (-not $pkg) { continue }

        [pscustomobject]@{
            SourceType    = 'Package'
            # Execution identity per §14.4: Package Name + Program Name
            Identity      = '{0} :: {1}' -f $pkg.Name, $prog.ProgramName
            MetadataLines = $lines
            Comment       = [ordered]@{
                'SourceType' = 'Package'
                'Package'    = $pkg.Name
                'Program'    = $prog.ProgramName
                'PackageID'  = $prog.PackageID
            }
            Execution     = [pscustomobject]@{
                Kind        = 'Package'
                ContentPath = $pkg.PkgSourcePath
                CommandLine = $prog.CommandLine
            }
        }
    }
}

function Get-TaggedApplicationDeploymentTypes {
    param([hashtable]$Config)
    Write-Host '  Scanning SCCM Application Deployment Types...' -ForegroundColor DarkGray

    # List latest app versions first (cheap), then pull SDMPackageXML per app.
    $apps = Invoke-AdminService -Config $Config -Query 'wmi/SMS_ApplicationLatest?$select=CI_ID,LocalizedDisplayName'

    foreach ($app in $apps) {
        # NOTE: SDMPackageXML is a LAZY property. The AdminService cannot
        # $select a lazy property (it 404s "Error waiting for query to
        # return"). Fetch the FULL instance with no $select — the provider
        # then hydrates lazy properties, including SDMPackageXML.
        $detail = Invoke-AdminService -Config $Config -Query "wmi/SMS_Application($($app.CI_ID))"
        # A keyed get may unwrap to a single object or a 1-element array.
        if ($detail -is [array]) { $detail = $detail | Select-Object -First 1 }
        if (-not $detail -or [string]::IsNullOrWhiteSpace($detail.SDMPackageXML)) { continue }

        [xml]$xml = $detail.SDMPackageXML
        $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
        $ns.AddNamespace('am', 'http://schemas.microsoft.com/SystemCenterConfigurationManager/2009/AppMgmtDigest')

        foreach ($dt in $xml.SelectNodes('//am:DeploymentType', $ns)) {
            # "Administrator comments" on the DT surfaces as its Description node
            $descNode = $dt.SelectSingleNode('am:Description', $ns)
            $lines = Get-MetadataLinesFromField -FieldText $(if ($descNode) { $descNode.InnerText } else { '' })
            if (-not $lines) { continue }

            $titleNode = $dt.SelectSingleNode('am:Title', $ns)
            $dtTitle   = if ($titleNode) { $titleNode.InnerText } else { '(unnamed DT)' }

            $installCmdNode = $dt.SelectSingleNode('.//am:InstallCommandLine', $ns)
            $installCmd     = if ($installCmdNode) { $installCmdNode.InnerText } else { $null }
            $locationNode   = $dt.SelectSingleNode('.//am:Contents/am:Content/am:Location', $ns)
            $contentPath    = if ($locationNode) { $locationNode.InnerText } else { $null }

            [pscustomobject]@{
                SourceType    = 'Application'
                # Execution identity per §14.4: App Name + Deployment Type Name
                Identity      = '{0} :: {1}' -f $app.LocalizedDisplayName, $dtTitle
                MetadataLines = $lines
                Comment       = [ordered]@{
                    'SourceType'     = 'Application'
                    'Application'    = $app.LocalizedDisplayName
                    'DeploymentType' = $dtTitle
                    'CI_ID'          = $app.CI_ID
                }
                Execution     = [pscustomobject]@{
                    Kind        = 'Application'
                    ContentPath = $contentPath
                    CommandLine = $installCmd
                }
            }
        }
    }
}

function Get-TaggedScripts {
    param([hashtable]$Config)
    Write-Host '  Scanning SCCM Scripts...' -ForegroundColor DarkGray

    $field   = $Config.MetadataFields.Script
    # NOTE: 'Script' (the script body) is a LAZY column. Selecting it in a
    # list/GetAll query fails: "select on lazy columns not supported for
    # GetAll requests." So list only the non-lazy columns here, then fetch
    # the body per-script (keyed get, no $select) ONLY for tagged scripts.
    $scripts = Invoke-AdminService -Config $Config -Query "wmi/SMS_Scripts?`$select=ScriptGuid,ScriptName,$field"

    foreach ($s in $scripts) {
        $lines = Get-MetadataLinesFromField -FieldText $s.$field
        if (-not $lines) { continue }

        # Only now — for a tagged script — fetch the lazy body via keyed get.
        $body = $null
        try {
            $full = Invoke-AdminService -Config $Config -Query "wmi/SMS_Scripts('$($s.ScriptGuid)')"
            if ($full -is [array]) { $full = $full | Select-Object -First 1 }
            $rawScript = if ($full) { $full.Script } else { $null }
        } catch {
            $rawScript = $null
        }

        # SMS_Scripts.Script is base64-encoded UTF-16LE (with BOM) script body
        if (-not [string]::IsNullOrWhiteSpace($rawScript)) {
            try {
                $bytes = [Convert]::FromBase64String($rawScript)
                $body  = [Text.Encoding]::Unicode.GetString($bytes).TrimStart([char]0xFEFF)
            } catch {
                $body = $rawScript   # already plain text
            }
        }

        [pscustomobject]@{
            SourceType    = 'Script'
            Identity      = $s.ScriptName          # §14.4: Script item = Script Name
            MetadataLines = $lines
            Comment       = [ordered]@{
                'SourceType' = 'Script'
                'Script'     = $s.ScriptName
                'ScriptGuid' = $s.ScriptGuid
            }
            Execution     = [pscustomobject]@{
                Kind       = 'Script'
                ScriptBody = $body
            }
        }
    }
}

# ══════════════════════════════════════════════════════════════════════
#  Resolution engine  (design doc §7 target precedence, §8 override,
#                      §12 fail-fast conflict rules)
# ══════════════════════════════════════════════════════════════════════
function Resolve-BuildItems {
    param(
        [Parameter(Mandatory)][object[]]$SccmItems,
        [Parameter(Mandatory)][string]$Target,
        [string]$OverrideValue,
        [Parameter(Mandatory)][string[]]$RingOrder
    )
    $Target   = $Target.ToUpper()
    $resolved = New-Object System.Collections.Generic.List[object]
    $errors   = New-Object System.Collections.Generic.List[string]

    foreach ($item in $SccmItems) {

        # ── Parse every metadata line on this execution unit ──────────
        $parsed = @()
        foreach ($line in $item.MetadataLines) {
            try   { $parsed += ConvertFrom-MetadataLine -Line $line -ItemIdentity $item.Identity }
            catch { $errors.Add($_.Exception.Message); continue }
        }
        if (-not $parsed) { continue }

        # ── Duplicate override detection (§12) — same unit, same scope ─
        $dupes = $parsed | Where-Object OverrideValue |
                 Group-Object Target, Ring, OverrideValue | Where-Object Count -gt 1
        foreach ($d in $dupes) {
            $errors.Add("VALIDATION [$($item.Identity)] duplicate override entries for scope '$($d.Name)'")
        }

        # ── Filter to requested target: specific match OR PX (§7) ─────
        $matching = $parsed | Where-Object { $_.Target -eq $Target -or $_.Target -eq $Script:CrossPlatform }
        if (-not $matching) { continue }

        # ── Specific-target-beats-PX, evaluated per execution unit ────
        if ($matching | Where-Object { $_.Target -eq $Target }) {
            $matching = $matching | Where-Object { $_.Target -eq $Target }
        }

        # ── Ring-by-ring candidate selection with override rules (§8) ─
        # (The same unit may legitimately appear in different rings only
        #  via distinct default lines; within one ring exactly one
        #  candidate must survive or generation fails.)
        foreach ($ringGroup in ($matching | Group-Object Ring)) {
            $candidates = $ringGroup.Group

            if ($OverrideValue) {
                $overrides = $candidates | Where-Object { $_.OverrideValue -eq $OverrideValue }
                if ($overrides) { $candidates = $overrides }
                else            { $candidates = $candidates | Where-Object { -not $_.OverrideValue } }
            }
            else {
                $candidates = $candidates | Where-Object { -not $_.OverrideValue }
            }

            if (-not $candidates) { continue }   # only override lines exist, none selected

            if (@($candidates).Count -gt 1) {
                $errors.Add(("VALIDATION [{0}] {1} effective candidates remain for Ring {2} after resolution: {3}" -f `
                    $item.Identity, @($candidates).Count, $ringGroup.Name,
                    (($candidates | ForEach-Object Raw) -join '  ||  ')))
                continue
            }

            $meta = $candidates[0]

            # ── Required SCCM source details must resolve (§12) ───────
            switch ($item.Execution.Kind) {
                'Script' {
                    if ([string]::IsNullOrWhiteSpace($item.Execution.ScriptBody)) {
                        $errors.Add("VALIDATION [$($item.Identity)] script body could not be resolved from SCCM")
                        continue
                    }
                }
                default {
                    if ([string]::IsNullOrWhiteSpace($item.Execution.CommandLine)) {
                        $errors.Add("VALIDATION [$($item.Identity)] install command line could not be resolved from SCCM")
                        continue
                    }
                    if ([string]::IsNullOrWhiteSpace($item.Execution.ContentPath)) {
                        $errors.Add("VALIDATION [$($item.Identity)] content source path could not be resolved from SCCM")
                        continue
                    }
                }
            }

            $resolved.Add([pscustomobject]@{
                Identity   = $item.Identity
                SourceType = $item.SourceType
                Comment    = $item.Comment
                Execution  = $item.Execution
                Meta       = $meta
            })
        }
    }

    # ── Fail fast: report EVERY problem found, then stop (§12) ───────
    if ($errors.Count -gt 0) {
        $msg = "Generation FAILED — {0} validation error(s):`n  {1}" -f $errors.Count, ($errors -join "`n  ")
        throw $msg
    }

    # ── Sort: Ring (config order), then numeric Order (§10.14) ───────
    $ringRank = @{}
    for ($i = 0; $i -lt $RingOrder.Count; $i++) { $ringRank[$RingOrder[$i].ToUpper()] = $i }

    $resolved | Sort-Object `
        @{ Expression = { if ($ringRank.ContainsKey($_.Meta.Ring)) { $ringRank[$_.Meta.Ring] } else { [int]::MaxValue } } },
        @{ Expression = { $_.Meta.Order } },
        @{ Expression = { $_.Identity } }
}

# ══════════════════════════════════════════════════════════════════════
#  Emitters — wrapper scripts + HCL build files + shared vars
# ══════════════════════════════════════════════════════════════════════
function Get-SafeFileName {
    param([string]$Name)
    ($Name -replace '[^\w\-\.]', '_') -replace '_{2,}', '_'
}

function New-InstallWrapperScript {
    <#  Writes the per-item PowerShell wrapper that actually runs inside
        the build VM. For Packages/Applications: map SCCM content share,
        copy content locally, execute the recorded command line, clean up.
        For Scripts: the SCCM script body verbatim.                     #>
    param(
        [Parameter(Mandatory)][object]$Item,
        [Parameter(Mandatory)][string]$ScriptsDir,
        [Parameter(Mandatory)][int]$Sequence
    )
    $fileName = '{0:d3}_{1}.ps1' -f $Sequence, (Get-SafeFileName $Item.Identity)
    $path     = Join-Path $ScriptsDir $fileName

    if ($Item.Execution.Kind -eq 'Script') {
        $header = @(
            '# ── Generated from SCCM Script ──────────────────────────────'
            "# Script:   $($Item.Comment['Script'])"
            "# Guid:     $($Item.Comment['ScriptGuid'])"
            "# Metadata: $($Item.Meta.Raw)"
            '# ─────────────────────────────────────────────────────────────'
            '$ErrorActionPreference = ''Stop'''
            ''
        ) -join "`r`n"
        Set-Content -Path $path -Value ($header + $Item.Execution.ScriptBody) -Encoding UTF8
        return $fileName
    }

    # Package / Application installer wrapper
    $content = @"
# ── Generated from SCCM $($Item.SourceType) ─────────────────────────────
$(($Item.Comment.GetEnumerator() | ForEach-Object { "# $($_.Key): $($_.Value)" }) -join "`r`n")
# Metadata: $($Item.Meta.Raw)
# ─────────────────────────────────────────────────────────────────────
`$ErrorActionPreference = 'Stop'
`$src   = '$($Item.Execution.ContentPath.TrimEnd('\'))'
`$local = Join-Path `$env:SystemDrive 'GoldsmithStage\$(Get-SafeFileName $Item.Identity)'

# Content share credentials arrive via Packer environment_vars
`$user = `$env:PKG_SHARE_USER
`$pass = `$env:PKG_SHARE_PASS
if ([string]::IsNullOrWhiteSpace(`$user)) { throw 'PKG_SHARE_USER not supplied' }
`$cred = New-Object pscredential(`$user, (ConvertTo-SecureString `$pass -AsPlainText -Force))

Write-Host "Staging content from `$src"
New-PSDrive -Name PKGSRC -PSProvider FileSystem -Root `$src -Credential `$cred | Out-Null
try {
    New-Item -ItemType Directory -Path `$local -Force | Out-Null
    Copy-Item -Path 'PKGSRC:\*' -Destination `$local -Recurse -Force
}
finally {
    Remove-PSDrive -Name PKGSRC -Force
}

Write-Host 'Executing install command'
Push-Location `$local
try {
    # Command line exactly as recorded in SCCM
    cmd.exe /c "$($Item.Execution.CommandLine -replace '"','""')"
    if (`$LASTEXITCODE -notin 0, 3010, 1641) {
        throw "Installer exit code `$LASTEXITCODE"
    }
    Write-Host "Install completed (exit `$LASTEXITCODE)"
}
finally {
    Pop-Location
    Remove-Item -Path `$local -Recurse -Force -ErrorAction SilentlyContinue
}
"@
    Set-Content -Path $path -Value $content -Encoding UTF8
    return $fileName
}

function New-RingBuildFile {
    <#  Emits build.<ring>.pkr.hcl — the COMPLETE build block for one
        ring, provisioner steps in resolved order, every step commented
        with its SCCM source (§11).                                     #>
    param(
        [Parameter(Mandatory)][string]$Ring,
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Items,
        [Parameter(Mandatory)][string]$RingDir,
        [Parameter(Mandatory)][string]$SourceRef,     # e.g. source.vsphere-iso.core
        [Parameter(Mandatory)][int]$PauseSeconds,
        [Parameter(Mandatory)][string]$GenerationStamp
    )
    $scriptsDir = Join-Path $RingDir 'scripts'
    New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null

    $hcl = New-Object System.Text.StringBuilder
    [void]$hcl.AppendLine('# ═══════════════════════════════════════════════════════════════════')
    [void]$hcl.AppendLine("# GENERATED FILE — do not edit by hand")
    [void]$hcl.AppendLine("# Ring: $Ring")
    [void]$hcl.AppendLine("# $GenerationStamp")
    [void]$hcl.AppendLine('# ═══════════════════════════════════════════════════════════════════')
    [void]$hcl.AppendLine('')
    [void]$hcl.AppendLine("build {")
    [void]$hcl.AppendLine("  name    = `"$($Ring.ToLower())`"")
    [void]$hcl.AppendLine("  sources = [`"$SourceRef`"]")
    [void]$hcl.AppendLine('')

    $seq = 0
    foreach ($item in $Items) {
        $seq += 10
        $wrapper = New-InstallWrapperScript -Item $item -ScriptsDir $scriptsDir -Sequence $seq

        # ── Step comment block (§11) ──────────────────────────────────
        [void]$hcl.AppendLine("  # ── Ring: $($item.Meta.Ring)  Order: $('{0:d2}' -f $item.Meta.Order) ─────────────────────────────")
        foreach ($kv in $item.Comment.GetEnumerator()) {
            [void]$hcl.AppendLine("  # $($kv.Key): $($kv.Value)")
        }
        [void]$hcl.AppendLine("  # Metadata: $($item.Meta.Raw)")

        # ── Reboot BEFORE (RB) — native step (§9.1) ───────────────────
        if ($item.Meta.Reboot -eq 'RB') {
            [void]$hcl.AppendLine('  provisioner "windows-restart" {   # Reboot BEFORE (RB)')
            [void]$hcl.AppendLine('    restart_timeout = "15m"')
            [void]$hcl.AppendLine('  }')
        }

        # ── The install/script step itself (§9.3) ─────────────────────
        [void]$hcl.AppendLine('  provisioner "powershell" {')
        [void]$hcl.AppendLine("    script            = `"`${path.root}/scripts/$wrapper`"")
        [void]$hcl.AppendLine('    elevated_user     = var.winrm_username')
        [void]$hcl.AppendLine('    elevated_password = var.winrm_password')
        if ($item.Execution.Kind -ne 'Script') {
            [void]$hcl.AppendLine('    environment_vars  = [')
            [void]$hcl.AppendLine('      "PKG_SHARE_USER=${var.content_share_username}",')
            [void]$hcl.AppendLine('      "PKG_SHARE_PASS=${var.content_share_password}",')
            [void]$hcl.AppendLine('    ]')
        }
        # ── Pause BEFORE (PB) — native pause_before (§9.2) ────────────
        if ($item.Meta.Pause -eq 'PB') {
            [void]$hcl.AppendLine("    pause_before      = `"${PauseSeconds}s`"   # Pause BEFORE (PB)")
        }
        [void]$hcl.AppendLine('  }')

        # ── Reboot AFTER (RA) — native step (§9.4) ────────────────────
        if ($item.Meta.Reboot -eq 'RA') {
            [void]$hcl.AppendLine('  provisioner "windows-restart" {   # Reboot AFTER (RA)')
            [void]$hcl.AppendLine('    restart_timeout = "15m"')
            [void]$hcl.AppendLine('  }')
        }

        # ── Pause AFTER (PA) — explicit generated sleep (§9.5) ────────
        if ($item.Meta.Pause -eq 'PA') {
            [void]$hcl.AppendLine('  provisioner "powershell" {   # Pause AFTER (PA) — intentional settle time')
            [void]$hcl.AppendLine("    inline = [`"Write-Host 'Pause after (PA) — sleeping ${PauseSeconds}s'; Start-Sleep -Seconds ${PauseSeconds}`"]")
            [void]$hcl.AppendLine('  }')
        }
        [void]$hcl.AppendLine('')
    }

    [void]$hcl.AppendLine('}')
    $buildFile = Join-Path $RingDir "build.$($Ring.ToLower()).pkr.hcl"
    Set-Content -Path $buildFile -Value $hcl.ToString() -Encoding UTF8
    return $buildFile
}

function New-SharedVarsFile {
    param(
        [Parameter(Mandatory)][hashtable]$VCenterConfig,
        [Parameter(Mandatory)][string]$VCenterName,
        [Parameter(Mandatory)][string]$OSFolder,
        [Parameter(Mandatory)][string]$Target,
        [string]$OverrideValue,
        [Parameter(Mandatory)][string]$OutputRoot,
        [Parameter(Mandatory)][string]$GenerationStamp
    )
    $isoPath = '{0}/{1}.iso' -f $VCenterConfig.DatastoreIsoPath, $OSFolder
    $vs      = $VCenterConfig

    $content = @"
# ═══════════════════════════════════════════════════════════════════
# GENERATED FILE — do not edit by hand
# $GenerationStamp
# vCenter: $VCenterName ($($vs.Server))
# ═══════════════════════════════════════════════════════════════════

os_folder        = "$OSFolder"
build_target     = "$Target"
override_value   = "$(if ($OverrideValue) { $OverrideValue } else { '' })"
os_iso_path      = "$isoPath"

vcenter_server   = "$($vs.Server)"
vsphere_datacenter = "$($vs.Datacenter)"
vsphere_cluster    = "$($vs.Cluster)"
vsphere_datastore  = "$($vs.Datastore)"
vsphere_folder     = "$($vs.Folder)"
vsphere_network    = "$($vs.Network)"
"@
    $path = Join-Path $OutputRoot 'vars.pkrvars.hcl'
    Set-Content -Path $path -Value $content -Encoding UTF8
    return $path
}

# ══════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════
Write-Host ''
Write-Host '═══ Goldsmith Generator — SCCM → HCL2 ═══════════════════════════' -ForegroundColor Cyan

$config = Get-BuildConfig -Path $ConfigPath
if (-not $OutputPath) { $OutputPath = Join-Path $PSScriptRoot $config.Paths.Output }

# ── Resolve which vCenter this build targets ──────────────────────────
if (-not $VCenter) { $VCenter = $config.DefaultVCenter }
if (-not $config.VCenters.ContainsKey($VCenter)) {
    throw ("Unknown vCenter '{0}'. Configured: {1}" -f $VCenter, (($config.VCenters.Keys | Sort-Object) -join ', '))
}
$vcConfig = $config.VCenters[$VCenter]
Write-Host "  vCenter: $VCenter ($($vcConfig.Server))" -ForegroundColor DarkGray

# ── Sanity: the OS folder must exist in the library ───────────────────
$osFolderPath = Join-Path $config.OSLibrary.SharePath $OSFolder
if (-not (Test-Path $osFolderPath)) {
    Write-Warning "OS folder not found at '$osFolderPath' — continuing (share may be offline from this session), but verify before building."
}

# ── 1-2. Scan SCCM ─────────────────────────────────────────────────────
Write-Host 'Scanning SCCM via AdminService...' -ForegroundColor White
$sccmItems = @()
$sccmItems += Get-TaggedApplicationDeploymentTypes -Config $config
$sccmItems += Get-TaggedPackagePrograms            -Config $config
$sccmItems += Get-TaggedScripts                    -Config $config
Write-Host ("  {0} tagged execution unit(s) found" -f $sccmItems.Count) -ForegroundColor DarkGray

# ── 3-6. Validate, filter, resolve, sort ──────────────────────────────
Write-Host "Resolving for Target=$Target$(if ($OverrideValue) { " Override=$OverrideValue" })..." -ForegroundColor White
$items = @(Resolve-BuildItems -SccmItems $sccmItems -Target $Target `
            -OverrideValue $OverrideValue -RingOrder $config.Rings)
Write-Host ("  {0} item(s) selected for this build" -f $items.Count) -ForegroundColor DarkGray

# ── DryRun: print the resolved plan and stop ──────────────────────────
if ($DryRun) {
    Write-Host ''
    Write-Host '── DRY RUN — resolved build plan ─────────────────────────────' -ForegroundColor Yellow
    $items | ForEach-Object {
        [pscustomobject]@{
            Ring     = $_.Meta.Ring
            Order    = $_.Meta.Order
            Reboot   = $_.Meta.Reboot
            Pause    = $_.Meta.Pause
            Override = $_.Meta.OverrideValue
            Type     = $_.SourceType
            Item     = $_.Identity
        }
    } | Format-Table -AutoSize
    Write-Host 'No files written (dry run).' -ForegroundColor Yellow
    return
}

# ── 7. Emit ────────────────────────────────────────────────────────────
$stamp = 'Generated {0:yyyy-MM-dd HH:mm:ss} | OSFolder={1} | Target={2} | Override={3} | vCenter={4}' -f `
            (Get-Date), $OSFolder, $Target, $(if ($OverrideValue) { $OverrideValue } else { '(none)' }), $VCenter

if (Test-Path $OutputPath) { Remove-Item $OutputPath -Recurse -Force }
New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null

$sourceRefByRing = @{}
for ($i = 0; $i -lt $config.Rings.Count; $i++) {
    $ring = $config.Rings[$i].ToUpper()
    $sourceRefByRing[$ring] = if ($i -eq 0) { "source.vsphere-iso.$($ring.ToLower())" }
                              else          { "source.vsphere-clone.$($ring.ToLower())" }
}

Write-Host 'Writing generated files...' -ForegroundColor White
foreach ($ring in $config.Rings) {
    $ring      = $ring.ToUpper()
    $ringItems = @($items | Where-Object { $_.Meta.Ring -eq $ring })
    $ringDir   = Join-Path $OutputPath $ring.ToLower()
    New-Item -ItemType Directory -Path $ringDir -Force | Out-Null

    $file = New-RingBuildFile -Ring $ring -Items $ringItems -RingDir $ringDir `
              -SourceRef $sourceRefByRing[$ring] -PauseSeconds $config.PauseSeconds `
              -GenerationStamp $stamp
    Write-Host ("  {0}  ({1} item(s))" -f $file, $ringItems.Count) -ForegroundColor DarkGray

    # Items in rings not present in config would be silently lost — check
}
$unknownRings = @($items | Where-Object { $_.Meta.Ring -notin ($config.Rings | ForEach-Object ToUpper) })
if ($unknownRings) {
    $names = ($unknownRings | ForEach-Object { "$($_.Identity) [Ring=$($_.Meta.Ring)]" }) -join ', '
    throw "VALIDATION: item(s) tagged with Ring(s) not present in config Rings list: $names"
}

$varsFile = New-SharedVarsFile -VCenterConfig $vcConfig -VCenterName $VCenter `
              -OSFolder $OSFolder -Target $Target `
              -OverrideValue $OverrideValue -OutputRoot $OutputPath -GenerationStamp $stamp
Write-Host "  $varsFile" -ForegroundColor DarkGray

# ── Generation manifest for audit ─────────────────────────────────────
$manifest = [pscustomobject]@{
    GeneratedAt   = (Get-Date).ToString('o')
    OSFolder      = $OSFolder
    Target        = $Target
    OverrideValue = $OverrideValue
    VCenter       = $VCenter
    VCenterServer = $vcConfig.Server
    Items         = $items | ForEach-Object {
        [ordered]@{
            Ring = $_.Meta.Ring; Order = $_.Meta.Order; Type = $_.SourceType
            Item = $_.Identity;  Metadata = $_.Meta.Raw
        }
    }
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OutputPath 'generation-manifest.json') -Encoding UTF8

Write-Host ''
Write-Host 'Generation complete.' -ForegroundColor Green
