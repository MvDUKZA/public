# Goldsmith — Packer + SCCM Golden Image Pipeline

Implements **"Packer and SCCM – Final Design v2"** — SCCM is the single
source of truth; a PowerShell generator compiles SCCM metadata into
native Packer HCL2; a chained ring build produces CORE → STD → DEV
templates from one command.

```
ISO library ──► DISM servicing ──► oscdimg ISO ──► CORE (vsphere-iso)
                                                      │ clone
SCCM metadata ──► Generator ──► HCL2 per ring ──►    STD (vsphere-clone)
 Target|Ring|Order|Reboot|Pause[|Override]            │ clone
                                                     DEV (vsphere-clone)
```

## Repository layout

```
Goldsmith\
├── Start-GoldsmithBuild.ps1        Orchestrator — runs the ring chain
├── Invoke-GoldsmithGenerator.ps1   SCCM → HCL2 compiler (the brain)
├── Invoke-GoldsmithServicing.ps1      Monthly DISM patch + oscdimg repack
├── config\
│   └── build-config.psd1        ALL environment-specific values
├── templates\                   STATIC HCL — written once
│   ├── core\  variables.pkr.hcl + sources.pkr.hcl   (vsphere-iso)
│   ├── std\   variables.pkr.hcl + sources.pkr.hcl   (vsphere-clone)
│   └── dev\   variables.pkr.hcl + sources.pkr.hcl   (vsphere-clone)
├── autounattend\
│   ├── autounattend.xml         Win11 unattended install (CORE only)
│   └── setup.ps1                WinRM bootstrap (first logon)
└── output\                      GENERATED — never commit
    ├── vars.pkrvars.hcl
    ├── core\ build.core.pkr.hcl + scripts\*.ps1
    ├── std\  build.std.pkr.hcl  + scripts\*.ps1
    └── dev\  build.dev.pkr.hcl  + scripts\*.ps1
```

## One-time setup

1. **Edit `config\build-config.psd1`** — AdminService URL, vSphere
   details, OS share path, datastore ISO folder.
2. **Set secrets as environment variables** on the jump box (never in
   files):
   ```powershell
   $env:PKR_VAR_vcenter_username        = 'administrator@vsphere.local'
   $env:PKR_VAR_vcenter_password        = '...'
   $env:PKR_VAR_winrm_password          = '...'   # must match autounattend.xml
   $env:PKR_VAR_content_share_username  = 'CONTOSO\svc-packer-read'
   $env:PKR_VAR_content_share_password  = '...'
   $env:PKR_SCCM_SHARE_USER             = 'CONTOSO\svc-packer-read'
   $env:PKR_SCCM_SHARE_PASS             = '...'
   ```
3. **Replace the password placeholder** in `autounattend\autounattend.xml`
   (`P@cker-Build-Passw0rd!`) and keep it in sync with
   `PKR_VAR_winrm_password`.
4. **Tag SCCM items** with metadata lines:
   - Application Deployment Type → *Administrator comments*
   - Package Program → *Comment*
   - Script → *Comment/Description*

   Format: `<Target>|<Ring>|<Order>|<Reboot>|<Pause>[|<OverrideValue>]`

   Examples:
   ```
   PX|CORE|10|NR|NP            cross-platform, everywhere
   PV|CORE|12|NR|NP            VDI-specific (beats the PX line)
   PS|STD|30|RA|NP             server, reboot after install
   PV|CORE|20|NR|NP|Marinus    engineer test override
   ```

## Monthly cycle

```powershell
# 1. After Patch Tuesday — service the base folder
.\Invoke-GoldsmithServicing.ps1 -BaseFolder Win11_Enterprise_24H2 `
    -CuPath \\server\Updates\2025-06\windows11-kb50xxxxx-x64.msu
#    → \\server\OS\Win11_Enterprise_24H2_0625\  +  ...0625.iso

# 2. Upload the ISO to the datastore (PowerCLI)
Connect-VIServer vcenter.contoso.local
$ds = Get-Datastore 'Datastore-ISO'
Copy-DatastoreItem '\\server\OS\Win11_Enterprise_24H2_0625.iso' `
    -Destination "$($ds.DatastoreBrowserPath)\packer\"

# 3. Preview exactly what will be installed (no files written)
.\Invoke-GoldsmithGenerator.ps1 -OSFolder Win11_Enterprise_24H2_0625 `
    -Target PV -DryRun

# 4. Run the full chain
.\Start-GoldsmithBuild.ps1 -OSFolder Win11_Enterprise_24H2_0625 -Target PV
#    → templates: ..._PV_CORE, ..._PV_STD, ..._PV_DEV
```

### Engineer override test

```powershell
.\Start-GoldsmithBuild.ps1 -OSFolder Win11_Enterprise_24H2_0625 `
    -Target PV -OverrideValue Marinus
```

### Resume after a ring failure

Completed templates stay committed in vSphere. If DEV failed:

```powershell
.\Start-GoldsmithBuild.ps1 -OSFolder Win11_Enterprise_24H2_0625 `
    -Target PV -SkipGenerate -StartFromRing DEV
```

## Validation (fail fast)

Generation refuses to produce a file if ANY tagged item has:
token count ≠ 5/6 · non-numeric Order · Reboot ∉ {NR,RB,RA} ·
Pause ∉ {NP,PB,PA} · duplicate override for the same scope ·
more than one effective candidate after resolution · unresolvable
SCCM source details · a Ring not present in the config Rings list.
**Every** error is reported in one pass, then generation stops.

## Design decisions worth remembering

- **No Windows Update during builds** — the ISO is pre-patched via DISM
  (SSU before CU, always). WinRM handles mid-build WU reboots badly.
- **Provisioners live in the generated file** — HCL2 requires
  provisioners inside the `build` block, so `build.<ring>.pkr.hcl` is
  generated whole. Sources and variables are static.
- **Chain is orchestrated in PowerShell** — Packer has no `depends_on`
  between builds; the orchestrator passes each ring's template name to
  the next ring's `vsphere-clone` source. Names are deterministic:
  `<OSFolder>_<Target>_<RING>`.
- **Content is copied locally before install** — wrapper scripts map the
  SCCM share with dedicated read-only credentials, robocopy content to
  `C:\PackerStage\`, run the recorded command line, clean up. UNC-direct
  installs are flaky; local installs are not.
- **Exit codes 0 / 3010 / 1641 are success** — 3010 and 1641 mean
  "reboot required", which the metadata's RA flag handles explicitly.

## Verify before first run

Two SCCM field mappings in `build-config.psd1` → `MetadataFields` should
be confirmed against your ConfigMgr version by tagging ONE test package
and running `-DryRun`: the Deployment Type comments node name inside
`SDMPackageXML`, and whether your site exposes Program comments as
`Comment` on `SMS_Program`. Both are config values — no code changes
needed if they differ.
