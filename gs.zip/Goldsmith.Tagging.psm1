<#
    Goldsmith.Tagging.psm1
    ─────────────────────────────────────────────────────────────────
    Pipeline-native SCCM metadata tagging for the Goldsmith image
    pipeline. Public cmdlets:

        Get-GoldsmithTag      read / audit  (pipeline OUT)
        Set-GoldsmithTag      add / replace (pipeline IN + OUT)
        Remove-GoldsmithTag   remove        (pipeline IN + OUT)
        Invoke-GoldsmithTagger   rich interactive wrapper (humans)

    Design:
      • Metadata (Target|Ring|Order|Reboot|Pause[|Override]) lives on
        the execution units: Deployment Types, Programs, Scripts.
      • An administrative Category ("Goldsmith") is stamped on the
        parent Application/Package as a fast findability index —
        applied automatically on Set, auto-cleaned on last Remove.
      • Reads filter by category first, so we never crawl the whole
        estate or parse SDMPackageXML for untagged apps.
#>

Set-StrictMode -Version Latest

# ══════════════════════════════════════════════════════════════════════
#  Module-scoped configuration
# ══════════════════════════════════════════════════════════════════════
$script:GoldsmithConfig = @{
    SiteCode            = 'PRD'
    ProviderMachineName = 'appsmcm101fp.iprod.local'
    AdminServiceUrl     = $null       # defaults to https://<provider>/AdminService
    CategoryName        = 'Goldsmith'
    Fields              = @{
        PackageProgram = 'Comment'
        Script         = 'Comment'
    }
}

# Canonical schema regex — single-quoted so nothing interpolates.
$script:MetadataRegex = '^(?<Target>[^|\r\n]+)\|(?<Ring>[^|\r\n]+)\|(?<Order>\d{2})\|(?<Reboot>NR|RB|RA)\|(?<Pause>NP|PB|PA)(?:\|(?<Override>[^|\r\n]+))?$'

$script:ValidReboot = @('NR', 'RB', 'RA')
$script:ValidPause  = @('NP', 'PB', 'PA')

# ══════════════════════════════════════════════════════════════════════
#  Configuration loader — pulls defaults from build-config.psd1 if found
# ══════════════════════════════════════════════════════════════════════
function Import-GoldsmithConfig {
    [CmdletBinding()]
    param([string]$ConfigPath)

    if (-not $ConfigPath) {
        # Module sits in <root>\Modules\Goldsmith.Tagging; config in <root>\config
        $root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
        $ConfigPath = Join-Path $root 'config\build-config.psd1'
    }
    if (-not (Test-Path $ConfigPath)) { return }

    try { $cfg = Import-PowerShellDataFile -Path $ConfigPath } catch { return }

    if ($cfg.ContainsKey('SccmSiteCode'))  { $script:GoldsmithConfig.SiteCode            = $cfg.SccmSiteCode }
    if ($cfg.ContainsKey('SccmProvider'))  { $script:GoldsmithConfig.ProviderMachineName = $cfg.SccmProvider }
    if ($cfg.ContainsKey('AdminService') -and $cfg.AdminService.ContainsKey('BaseUrl')) {
        $script:GoldsmithConfig.AdminServiceUrl = $cfg.AdminService.BaseUrl
    }
    if ($cfg.ContainsKey('GoldsmithCategory')) { $script:GoldsmithConfig.CategoryName = $cfg.GoldsmithCategory }
    if ($cfg.ContainsKey('MetadataFields')) {
        if ($cfg.MetadataFields.ContainsKey('PackageProgram')) { $script:GoldsmithConfig.Fields.PackageProgram = $cfg.MetadataFields.PackageProgram }
        if ($cfg.MetadataFields.ContainsKey('Script'))         { $script:GoldsmithConfig.Fields.Script         = $cfg.MetadataFields.Script }
    }
}

# ══════════════════════════════════════════════════════════════════════
#  Small shared primitives
# ══════════════════════════════════════════════════════════════════════
function Test-GoldsmithBlank {
    param([AllowNull()][string]$Value)
    return [string]::IsNullOrWhiteSpace($Value)
}

function Test-GoldsmithMetadataLine {
    param([Parameter(Mandatory)][string]$Line)
    return ($Line -match $script:MetadataRegex)
}

function New-GoldsmithMetadataLine {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Target,
        [Parameter(Mandatory)][string]$Ring,
        [Parameter(Mandatory)][ValidatePattern('^\d{1,2}$')][string]$Order,
        [Parameter(Mandatory)][ValidateSet('NR', 'RB', 'RA')][string]$Reboot,
        [Parameter(Mandatory)][ValidateSet('NP', 'PB', 'PA')][string]$Pause,
        [string]$OverrideValue
    )
    $orderPadded = '{0:D2}' -f [int]$Order
    $base = '{0}|{1}|{2}|{3}|{4}' -f $Target.Trim().ToUpper(), $Ring.Trim().ToUpper(), $orderPadded, $Reboot, $Pause
    if (Test-GoldsmithBlank $OverrideValue) { return $base }
    return '{0}|{1}' -f $base, $OverrideValue.Trim()
}

function ConvertTo-GoldsmithPreview {
    param([AllowNull()][string]$Text, [int]$MaxLength = 120)
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    $lines = foreach ($line in ($Text -split "`r?`n")) {
        if ($line -match $script:MetadataRegex) { $line.Trim() }
    }
    if (-not $lines) { return '' }
    $preview = $lines -join '; '
    if ($preview.Length -gt $MaxLength) { return $preview.Substring(0, $MaxLength - 3) + '...' }
    return $preview
}

# ── Scope key = Target + Ring + Override (one line per scope per item) ──
function Get-GoldsmithScopeKey {
    param([Parameter(Mandatory)][string]$Line)
    if ($Line -notmatch $script:MetadataRegex) { return $null }
    $ov = if ($Matches.Override) { $Matches.Override.Trim() } else { '' }
    return ('{0}|{1}|{2}' -f $Matches.Target.Trim().ToUpper(), $Matches.Ring.Trim().ToUpper(), $ov)
}

# ══════════════════════════════════════════════════════════════════════
#  Merge — add / replace / remove one scoped line within a comment field
# ══════════════════════════════════════════════════════════════════════
function Merge-GoldsmithMetadataText {
    [CmdletBinding()]
    param(
        [AllowNull()][string]$CurrentText,
        [string]$NewMetadataLine,           # empty when removing
        [Parameter(Mandatory)][string]$ScopeKey,
        [switch]$RemoveOnly
    )
    $lines = if ([string]::IsNullOrWhiteSpace($CurrentText)) { @() } else { $CurrentText -split "`r?`n" }
    $meta  = [System.Collections.Generic.List[string]]::new()
    $other = [System.Collections.Generic.List[string]]::new()
    $existing = $null

    foreach ($line in $lines) {
        $t = $line.TrimEnd()
        if (-not $t) { continue }
        if (Test-GoldsmithMetadataLine $t) {
            if ((Get-GoldsmithScopeKey $t) -eq $ScopeKey) {
                if (-not $existing) { $existing = $t }
                continue
            }
            $meta.Add($t) | Out-Null
        }
        else { $other.Add($t) | Out-Null }
    }

    if ($RemoveOnly) {
        $updated = (($meta + $other) -join [Environment]::NewLine).TrimEnd()
        return [pscustomobject]@{
            UpdatedText  = $updated
            Changed      = [bool]$existing
            ExistingLine = $existing
            RemainingTagCount = $meta.Count
        }
    }

    $out = [System.Collections.Generic.List[string]]::new()
    $out.Add($NewMetadataLine) | Out-Null
    foreach ($l in $meta)  { $out.Add($l) | Out-Null }
    foreach ($l in $other) { $out.Add($l) | Out-Null }
    $updated = ($out.ToArray() -join [Environment]::NewLine).TrimEnd()
    return [pscustomobject]@{
        UpdatedText  = $updated
        Changed      = ($existing -ne $NewMetadataLine)
        ExistingLine = $existing
        RemainingTagCount = $meta.Count + 1
    }
}

# ══════════════════════════════════════════════════════════════════════
#  AdminService read layer (fast, read-only, category-filtered)
# ══════════════════════════════════════════════════════════════════════
function Get-GoldsmithAdminServiceUrl {
    $url = $script:GoldsmithConfig.AdminServiceUrl
    if (-not $url) { $url = "https://$($script:GoldsmithConfig.ProviderMachineName)/AdminService" }
    return $url.TrimEnd('/')
}

function Invoke-GoldsmithAdminService {
    param([Parameter(Mandatory)][string]$Query)
    $uri = '{0}/{1}' -f (Get-GoldsmithAdminServiceUrl), $Query
    $resp = Invoke-RestMethod -Method Get -Uri $uri -UseDefaultCredentials
    if ($null -ne $resp.PSObject.Properties['value']) { return $resp.value }
    return $resp
}

# ══════════════════════════════════════════════════════════════════════
#  ConfigMgr console context (needed only for writes)
# ══════════════════════════════════════════════════════════════════════
function Initialize-GoldsmithConfigMgr {
    [CmdletBinding()]
    param()
    if (-not (Get-Module ConfigurationManager)) {
        if (Get-Module -ListAvailable -Name ConfigurationManager) {
            Import-Module ConfigurationManager -ErrorAction Stop
        }
        elseif ($env:SMS_ADMIN_UI_PATH) {
            Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1') -ErrorAction Stop
        }
        else {
            throw 'ConfigurationManager module not found. Install the ConfigMgr console on this machine to write tags (reads via -List work without it).'
        }
    }
    $site = $script:GoldsmithConfig.SiteCode
    if (-not (Get-PSDrive -Name $site -ErrorAction SilentlyContinue)) {
        New-PSDrive -Name $site -PSProvider CMSite -Root $script:GoldsmithConfig.ProviderMachineName -Scope Global | Out-Null
    }
}

# Run a scriptblock inside the CMSite drive, then restore location.
function Invoke-GoldsmithInCMContext {
    [CmdletBinding()]
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)
    Initialize-GoldsmithConfigMgr
    $prev = (Get-Location).Path
    try {
        Set-Location ("{0}:\" -f $script:GoldsmithConfig.SiteCode)
        & $ScriptBlock
    }
    finally { Set-Location $prev }
}

# ══════════════════════════════════════════════════════════════════════
#  Administrative Category management (the findability index)
# ══════════════════════════════════════════════════════════════════════
function Confirm-GoldsmithCategoryExists {
    [CmdletBinding()]
    param()
    $name = $script:GoldsmithConfig.CategoryName
    $existing = Get-CMCategory -Name $name -ErrorAction SilentlyContinue
    if (-not $existing) {
        New-CMCategory -CategoryType AppCategories -Name $name -ErrorAction Stop | Out-Null
    }
}

function Add-GoldsmithCategoryToParent {
    <# Stamp the Goldsmith category on the parent Application (by name).
       Packages don't support admin categories the same way, so this is
       Application-only; Package findability comes from the Program tag
       audit instead. #>
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$ApplicationName)

    $name = $script:GoldsmithConfig.CategoryName
    $app  = Get-CMApplication -Name $ApplicationName -ErrorAction SilentlyContinue
    if (-not $app) { return }

    $current = @()
    if ($app.PSObject.Properties.Name -contains 'LocalizedCategoryInstanceNames' -and $app.LocalizedCategoryInstanceNames) {
        $current = @($app.LocalizedCategoryInstanceNames)
    }
    if ($current -contains $name) { return }   # already tagged

    if ($PSCmdlet.ShouldProcess($ApplicationName, "Add administrative category '$name'")) {
        Confirm-GoldsmithCategoryExists
        Set-CMApplication -Name $ApplicationName -AppCategory ($current + $name) -ErrorAction Stop
    }
}

function Remove-GoldsmithCategoryFromParent {
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$ApplicationName)

    $name = $script:GoldsmithConfig.CategoryName
    $app  = Get-CMApplication -Name $ApplicationName -ErrorAction SilentlyContinue
    if (-not $app) { return }
    $current = @()
    if ($app.PSObject.Properties.Name -contains 'LocalizedCategoryInstanceNames' -and $app.LocalizedCategoryInstanceNames) {
        $current = @($app.LocalizedCategoryInstanceNames)
    }
    if ($current -notcontains $name) { return }

    $remaining = @($current | Where-Object { $_ -ne $name })
    if ($PSCmdlet.ShouldProcess($ApplicationName, "Remove administrative category '$name'")) {
        Set-CMApplication -Name $ApplicationName -AppCategory $remaining -ErrorAction Stop
    }
}

# Does any Deployment Type on this app still carry a Goldsmith tag?
function Test-GoldsmithAppHasAnyTag {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ApplicationName)
    $dts = @(Get-CMDeploymentType -ApplicationName $ApplicationName -ErrorAction SilentlyContinue)
    foreach ($dt in $dts) {
        $comment = Get-GoldsmithDeploymentTypeComment -DeploymentType $dt
        foreach ($line in ($comment -split "`r?`n")) {
            if (Test-GoldsmithMetadataLine ($line.Trim())) { return $true }
        }
    }
    return $false
}

# ══════════════════════════════════════════════════════════════════════
#  Identity + comment read/write per execution-unit type
# ══════════════════════════════════════════════════════════════════════
function Get-GoldsmithDeploymentTypeIdentity {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$DeploymentType)

    $dtName = if ($DeploymentType.PSObject.Properties.Name -contains 'LocalizedDisplayName' -and -not (Test-GoldsmithBlank $DeploymentType.LocalizedDisplayName)) {
        [string]$DeploymentType.LocalizedDisplayName
    }
    elseif ($DeploymentType.PSObject.Properties.Name -contains 'DeploymentTypeName' -and -not (Test-GoldsmithBlank $DeploymentType.DeploymentTypeName)) {
        [string]$DeploymentType.DeploymentTypeName
    }
    else { '' }

    $appName = ''
    if ($DeploymentType.PSObject.Properties.Name -contains 'ApplicationName' -and -not (Test-GoldsmithBlank $DeploymentType.ApplicationName)) {
        $appName = [string]$DeploymentType.ApplicationName
    }
    if (Test-GoldsmithBlank $appName) {
        try {
            $parent = Get-CMApplication -InputObject $DeploymentType -Fast -ErrorAction Stop
            if ($parent -and $parent.PSObject.Properties.Name -contains 'LocalizedDisplayName') {
                $appName = [string]$parent.LocalizedDisplayName
            }
        } catch { }
    }
    [pscustomobject]@{ ApplicationName = $appName; DeploymentTypeName = $dtName }
}

function Get-GoldsmithDeploymentTypeComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$DeploymentType)
    try {
        if ($DeploymentType.PSObject.Methods.Name -contains 'Get') { $DeploymentType.Get() }
    } catch { }
    foreach ($prop in 'AdministratorComment', 'AdminComment') {
        if ($DeploymentType.PSObject.Properties.Name -contains $prop) { return [string]$DeploymentType.$prop }
    }
    return [string]::Empty
}

function Set-GoldsmithDeploymentTypeComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$DeploymentType, [Parameter(Mandatory)][AllowEmptyString()][string]$CommentText)
    $id = Get-GoldsmithDeploymentTypeIdentity -DeploymentType $DeploymentType
    if (Test-GoldsmithBlank $id.ApplicationName)    { throw 'Unable to resolve ApplicationName for Set-CMDeploymentType.' }
    if (Test-GoldsmithBlank $id.DeploymentTypeName) { throw 'Unable to resolve DeploymentTypeName for Set-CMDeploymentType.' }
    Set-CMDeploymentType -ApplicationName $id.ApplicationName -DeploymentTypeName $id.DeploymentTypeName -AdministratorComment $CommentText -Confirm:$false | Out-Null
}

function Get-GoldsmithProgramComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Program)
    if ($Program.PSObject.Properties.Name -contains 'Comment') { return [string]$Program.Comment }
    return [string]::Empty
}

function Set-GoldsmithProgramComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Program, [Parameter(Mandatory)][AllowEmptyString()][string]$CommentText)
    $pkgId = if ($Program.PSObject.Properties.Name -contains 'PackageID')   { [string]$Program.PackageID }   else { '' }
    $prgNm = if ($Program.PSObject.Properties.Name -contains 'ProgramName') { [string]$Program.ProgramName } else { '' }
    if (Test-GoldsmithBlank $pkgId) { throw 'Unable to resolve PackageID for Set-CMProgram.' }
    if (Test-GoldsmithBlank $prgNm) { throw 'Unable to resolve ProgramName for Set-CMProgram.' }

    $isStandard = $true
    if ($Program.PSObject.Properties.Name -contains 'ProgramFlags') {
        try { $isStandard = -not ([bool]($Program.ProgramFlags -band 0x00001000)) } catch { $isStandard = $true }
    }
    if ($isStandard) {
        Set-CMProgram -PackageId $pkgId -ProgramName $prgNm -StandardProgram -Comment $CommentText -Confirm:$false | Out-Null
    } else {
        Set-CMProgram -PackageId $pkgId -ProgramName $prgNm -Comment $CommentText -Confirm:$false | Out-Null
    }
}

function Get-GoldsmithScriptRecord {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$ScriptObject)
    $ns = "root\SMS\site_$($script:GoldsmithConfig.SiteCode)"
    $guid = $null
    foreach ($prop in 'ScriptGuid', 'Guid') {
        if ($ScriptObject.PSObject.Properties.Name -contains $prop -and -not (Test-GoldsmithBlank $ScriptObject.$prop)) {
            $guid = [string]$ScriptObject.$prop; break
        }
    }
    if (-not (Test-GoldsmithBlank $guid)) {
        try {
            return Get-CimInstance -ComputerName $script:GoldsmithConfig.ProviderMachineName -Namespace $ns -ClassName SMS_Scripts -Filter ("ScriptGuid='{0}'" -f $guid) -ErrorAction Stop
        } catch { }
    }
    if ($ScriptObject.PSObject.Properties.Name -contains 'ScriptName' -and -not (Test-GoldsmithBlank $ScriptObject.ScriptName)) {
        $esc = $ScriptObject.ScriptName.Replace("'", "''")
        return Get-CimInstance -ComputerName $script:GoldsmithConfig.ProviderMachineName -Namespace $ns -ClassName SMS_Scripts -Filter ("ScriptName='{0}'" -f $esc) -ErrorAction Stop
    }
    throw 'Unable to resolve SMS_Scripts record.'
}

function Get-GoldsmithScriptComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$ScriptObject)
    $rec = Get-GoldsmithScriptRecord -ScriptObject $ScriptObject
    foreach ($prop in 'Comment', 'Description') {
        if ($rec.PSObject.Properties.Name -contains $prop) { return [string]$rec.$prop }
    }
    return [string]::Empty
}

function Set-GoldsmithScriptComment {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$ScriptObject, [Parameter(Mandatory)][AllowEmptyString()][string]$CommentText)
    $rec = Get-GoldsmithScriptRecord -ScriptObject $ScriptObject
    $prop = if ($rec.PSObject.Properties.Name -contains 'Comment') { 'Comment' } else { 'Description' }
    $rec.$prop = $CommentText
    Set-CimInstance -InputObject $rec -ErrorAction Stop | Out-Null
}

# Classify an arbitrary piped SCCM object.
function Resolve-GoldsmithObjectType {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Object)
    $p = @($Object.PSObject.Properties.Name)
    if ($p -contains 'ScriptName') { return 'Script' }
    if ($p -contains 'ProgramName' -and ($p -contains 'PackageID' -or $p -contains 'PackageId')) { return 'Program' }
    if (($p -contains 'LocalizedDisplayName' -or $p -contains 'DeploymentTypeName') -and ($p -notcontains 'ScriptName')) { return 'DeploymentType' }
    return 'Unknown'
}

# ══════════════════════════════════════════════════════════════════════
#  PUBLIC: Get-GoldsmithTag  — read / audit, pipeline OUT
# ══════════════════════════════════════════════════════════════════════
function Get-GoldsmithTag {
    <#
    .SYNOPSIS
        List Goldsmith metadata tags across SCCM. Read-only, fast.
    .DESCRIPTION
        Uses the AdminService. Applications are filtered to the Goldsmith
        administrative category FIRST, so only tagged apps have their
        Deployment Types expanded — no full-estate SDMPackageXML crawl.
        Emits one object per metadata line; pipe to Where-Object,
        Export-Csv, or straight into Set/Remove-GoldsmithTag.
    .PARAMETER Ring
        Filter results to a ring (CORE/STD/DEV/...).
    .PARAMETER Target
        Filter results to a target token (PV/PS/PD/PL/PX).
    .PARAMETER Override
        Filter results to a specific override value.
    .PARAMETER Type
        Limit to Application, Package, or Script.
    .EXAMPLE
        Get-GoldsmithTag | Format-Table
    .EXAMPLE
        Get-GoldsmithTag -Ring STD | Export-Csv .\std-tags.csv -NoTypeInformation
    #>
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [string]$Ring,
        [string]$Target,
        [string]$Override,
        [ValidateSet('Application', 'Package', 'Script')]
        [string[]]$Type,
        [string]$ConfigPath
    )

    Import-GoldsmithConfig -ConfigPath $ConfigPath
    $catName = $script:GoldsmithConfig.CategoryName
    $wantTypes = if ($Type) { $Type } else { @('Application', 'Package', 'Script') }

    $emit = {
        param($row)
        # optional client-side filters
        if ($Ring     -and $row.Ring     -ne $Ring.ToUpper())     { return }
        if ($Target   -and $row.Target   -ne $Target.ToUpper())   { return }
        if ($Override -and $row.Override -ne $Override)           { return }
        $row
    }

    # ── Applications: filter by category, expand only those ────────────
    if ($wantTypes -contains 'Application') {
        $apps = Invoke-GoldsmithAdminService -Query 'wmi/SMS_ApplicationLatest?$select=CI_ID,LocalizedDisplayName,LocalizedCategoryInstanceNames'
        foreach ($a in $apps) {
            $cats = @()
            if ($a.PSObject.Properties.Name -contains 'LocalizedCategoryInstanceNames' -and $a.LocalizedCategoryInstanceNames) {
                $cats = @($a.LocalizedCategoryInstanceNames)
            }
            if ($cats -notcontains $catName) { continue }   # fast skip — no XML fetch

            # SDMPackageXML is a LAZY property — cannot be $select'd via the
            # AdminService (404 "Error waiting for query to return"). Fetch the
            # full instance so the provider hydrates it.
            $detail = Invoke-GoldsmithAdminService -Query "wmi/SMS_Application($($a.CI_ID))"
            if ($detail -is [array]) { $detail = $detail | Select-Object -First 1 }
            if (-not $detail -or [string]::IsNullOrWhiteSpace($detail.SDMPackageXML)) { continue }
            [xml]$xml = $detail.SDMPackageXML
            $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
            $ns.AddNamespace('am', 'http://schemas.microsoft.com/SystemCenterConfigurationManager/2009/AppMgmtDigest')
            foreach ($dt in $xml.SelectNodes('//am:DeploymentType', $ns)) {
                $desc = $dt.SelectSingleNode('am:Description', $ns)
                if (-not $desc) { continue }
                $titleNode = $dt.SelectSingleNode('am:Title', $ns)
                $dtTitle = if ($titleNode) { $titleNode.InnerText } else { '(unnamed DT)' }
                foreach ($line in ($desc.InnerText -split "`r?`n")) {
                    $t = $line.Trim()
                    if (-not (Test-GoldsmithMetadataLine $t)) { continue }
                    $null = $t -match $script:MetadataRegex
                    $row = [pscustomobject]@{
                        Type       = 'Application'
                        Item       = '{0} :: {1}' -f $a.LocalizedDisplayName, $dtTitle
                        Target     = $Matches.Target.ToUpper()
                        Ring       = $Matches.Ring.ToUpper()
                        Order      = [int]$Matches.Order
                        Reboot     = $Matches.Reboot
                        Pause      = $Matches.Pause
                        Override   = if ($Matches.Override) { $Matches.Override } else { '' }
                        Metadata   = $t
                    }
                    & $emit $row
                }
            }
        }
    }

    # ── Packages: no category surface, so scan programs directly ───────
    if ($wantTypes -contains 'Package') {
        $fld = $script:GoldsmithConfig.Fields.PackageProgram
        $pkgNames = @{}
        Invoke-GoldsmithAdminService -Query 'wmi/SMS_Package?$select=PackageID,Name' | ForEach-Object { $pkgNames[$_.PackageID] = $_.Name }
        foreach ($p in (Invoke-GoldsmithAdminService -Query "wmi/SMS_Program?`$select=PackageID,ProgramName,$fld")) {
            foreach ($line in ($p.$fld -split "`r?`n")) {
                $t = $line.Trim()
                if (-not (Test-GoldsmithMetadataLine $t)) { continue }
                $null = $t -match $script:MetadataRegex
                $itemName = '{0} :: {1}' -f $pkgNames[$p.PackageID], $p.ProgramName
                $row = [pscustomobject]@{
                    Type = 'Package'; Item = $itemName
                    Target = $Matches.Target.ToUpper(); Ring = $Matches.Ring.ToUpper()
                    Order = [int]$Matches.Order; Reboot = $Matches.Reboot; Pause = $Matches.Pause
                    Override = if ($Matches.Override) { $Matches.Override } else { '' }
                    Metadata = $t
                }
                & $emit $row
            }
        }
    }

    # ── Scripts ────────────────────────────────────────────────────────
    if ($wantTypes -contains 'Script') {
        $fld = $script:GoldsmithConfig.Fields.Script
        foreach ($s in (Invoke-GoldsmithAdminService -Query "wmi/SMS_Scripts?`$select=ScriptName,$fld")) {
            foreach ($line in ($s.$fld -split "`r?`n")) {
                $t = $line.Trim()
                if (-not (Test-GoldsmithMetadataLine $t)) { continue }
                $null = $t -match $script:MetadataRegex
                $row = [pscustomobject]@{
                    Type = 'Script'; Item = $s.ScriptName
                    Target = $Matches.Target.ToUpper(); Ring = $Matches.Ring.ToUpper()
                    Order = [int]$Matches.Order; Reboot = $Matches.Reboot; Pause = $Matches.Pause
                    Override = if ($Matches.Override) { $Matches.Override } else { '' }
                    Metadata = $t
                }
                & $emit $row
            }
        }
    }
}

# ══════════════════════════════════════════════════════════════════════
#  Shared apply-engine used by Set and Remove
# ══════════════════════════════════════════════════════════════════════
function Invoke-GoldsmithApply {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Object,          # DT / Program / Script
        [Parameter(Mandatory)][string]$NewLine, # '' when removing
        [Parameter(Mandatory)][string]$ScopeKey,
        [switch]$RemoveMode,
        [Parameter(Mandatory)][System.Management.Automation.PSCmdlet]$Caller
    )
    $resolved = Resolve-GoldsmithObjectType -Object $Object
    switch ($resolved) {
        'DeploymentType' {
            $id = Get-GoldsmithDeploymentTypeIdentity -DeploymentType $Object
            $identity = 'Application=[{0}] DeploymentType=[{1}]' -f $id.ApplicationName, $id.DeploymentTypeName
            $current  = Get-GoldsmithDeploymentTypeComment -DeploymentType $Object
        }
        'Program' {
            $pkg = if ($Object.PSObject.Properties.Name -contains 'PackageName') { $Object.PackageName } else { '' }
            $prg = if ($Object.PSObject.Properties.Name -contains 'ProgramName') { $Object.ProgramName } else { '' }
            $identity = 'Package=[{0}] Program=[{1}]' -f $pkg, $prg
            $current  = Get-GoldsmithProgramComment -Program $Object
        }
        'Script' {
            $sn = if ($Object.PSObject.Properties.Name -contains 'ScriptName') { $Object.ScriptName } else { '<unknown>' }
            $identity = 'Script=[{0}]' -f $sn
            $current  = Get-GoldsmithScriptComment -ScriptObject $Object
        }
        default {
            Write-Warning "Skipping unsupported object (type '$resolved')."
            return
        }
    }

    $merge = Merge-GoldsmithMetadataText -CurrentText $current -NewMetadataLine $NewLine -ScopeKey $ScopeKey -RemoveOnly:$RemoveMode

    $result = [pscustomobject]@{
        Item     = $identity
        Type     = $resolved
        Action   = if ($RemoveMode) { if ($merge.Changed) { 'Removed' } else { 'NotFound' } }
                   else             { if ($merge.ExistingLine) { 'Replaced' } else { 'Added' } }
        Metadata = if ($RemoveMode) { $merge.ExistingLine } else { $NewLine }
        Changed  = $merge.Changed
    }

    if (-not $merge.Changed) { return $result }

    $verb = if ($RemoveMode) { 'Remove Goldsmith tag' } else { 'Set Goldsmith tag' }
    if (-not $Caller.ShouldProcess($identity, $verb)) {
        $result.Action = 'WhatIf'
        return $result
    }

    # ── Write the comment field ────────────────────────────────────────
    switch ($resolved) {
        'DeploymentType' { Set-GoldsmithDeploymentTypeComment -DeploymentType $Object -CommentText $merge.UpdatedText }
        'Program'        { Set-GoldsmithProgramComment        -Program $Object        -CommentText $merge.UpdatedText }
        'Script'         { Set-GoldsmithScriptComment         -ScriptObject $Object   -CommentText $merge.UpdatedText }
    }

    # ── Category upkeep (Applications only) ────────────────────────────
    if ($resolved -eq 'DeploymentType' -and -not (Test-GoldsmithBlank $id.ApplicationName)) {
        if ($RemoveMode) {
            # auto-clean: drop category once no DT on the app carries a tag
            if (-not (Test-GoldsmithAppHasAnyTag -ApplicationName $id.ApplicationName)) {
                Remove-GoldsmithCategoryFromParent -ApplicationName $id.ApplicationName
                $result | Add-Member -NotePropertyName CategoryAction -NotePropertyValue 'Removed (last tag)' -Force
            }
        }
        else {
            Add-GoldsmithCategoryToParent -ApplicationName $id.ApplicationName
            $result | Add-Member -NotePropertyName CategoryAction -NotePropertyValue 'Ensured' -Force
        }
    }

    return $result
}

# ══════════════════════════════════════════════════════════════════════
#  PUBLIC: Set-GoldsmithTag  — add / replace, pipeline IN + OUT
# ══════════════════════════════════════════════════════════════════════
function Set-GoldsmithTag {
    <#
    .SYNOPSIS
        Add or replace a Goldsmith metadata tag on SCCM objects.
    .DESCRIPTION
        Accepts Deployment Type / Program / Script objects from the
        pipeline (e.g. Get-CMDeploymentType), builds a validated tag
        line, and writes it. On Applications the Goldsmith category is
        applied to the parent automatically for fast future lookups.
        Emits a result object per item (pipe on or capture).
    .EXAMPLE
        Get-CMApplication '7-Zip' | Get-CMDeploymentType |
            Set-GoldsmithTag -Target PV -Ring CORE -Order 30
    .EXAMPLE
        Get-GoldsmithTag -Ring STD | Set-GoldsmithTag -Order 50 -PassThru
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [object]$InputObject,

        [Parameter(Mandatory)][string]$Target,
        [Parameter(Mandatory)][string]$Ring,
        [Parameter(Mandatory)][ValidatePattern('^\d{1,2}$')][string]$Order,
        [ValidateSet('NR', 'RB', 'RA')][string]$Reboot = 'NR',
        [ValidateSet('NP', 'PB', 'PA')][string]$Pause  = 'NP',
        [string]$OverrideValue,
        [string]$ConfigPath
    )
    begin {
        Import-GoldsmithConfig -ConfigPath $ConfigPath
        $newLine  = New-GoldsmithMetadataLine -Target $Target -Ring $Ring -Order $Order -Reboot $Reboot -Pause $Pause -OverrideValue $OverrideValue
        $scopeKey = Get-GoldsmithScopeKey $newLine
        $needCtx  = $true
    }
    process {
        foreach ($obj in $InputObject) {
            if ($needCtx) { Initialize-GoldsmithConfigMgr; $needCtx = $false }
            $prev = (Get-Location).Path
            try {
                Set-Location ("{0}:\" -f $script:GoldsmithConfig.SiteCode)
                $live = Resolve-GoldsmithRowToObject -Row $obj
                if ($null -eq $live) { continue }
                Invoke-GoldsmithApply -Object $live -NewLine $newLine -ScopeKey $scopeKey -Caller $PSCmdlet
            }
            finally { Set-Location $prev }
        }
    }
}

# ══════════════════════════════════════════════════════════════════════
#  PUBLIC: Remove-GoldsmithTag  — remove, pipeline IN + OUT
# ══════════════════════════════════════════════════════════════════════
function Remove-GoldsmithTag {
    <#
    .SYNOPSIS
        Remove the Goldsmith tag matching Target+Ring(+Override).
    .DESCRIPTION
        Accepts objects from the pipeline (including Get-GoldsmithTag
        output). Removes the scoped tag line; when the last tag on an
        Application's Deployment Types is removed, the Goldsmith
        category is stripped from the parent automatically.
    .EXAMPLE
        Get-GoldsmithTag -Override Marinus | Remove-GoldsmithTag -WhatIf
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [object]$InputObject,

        [Parameter(Mandatory)][string]$Target,
        [Parameter(Mandatory)][string]$Ring,
        [string]$OverrideValue,
        [string]$ConfigPath
    )
    begin {
        Import-GoldsmithConfig -ConfigPath $ConfigPath
        $ov = if (Test-GoldsmithBlank $OverrideValue) { '' } else { $OverrideValue.Trim() }
        $scopeKey = '{0}|{1}|{2}' -f $Target.Trim().ToUpper(), $Ring.Trim().ToUpper(), $ov
        $needCtx = $true
    }
    process {
        foreach ($obj in $InputObject) {
            if ($needCtx) { Initialize-GoldsmithConfigMgr; $needCtx = $false }
            $prev = (Get-Location).Path
            try {
                Set-Location ("{0}:\" -f $script:GoldsmithConfig.SiteCode)
                $live = Resolve-GoldsmithRowToObject -Row $obj
                if ($null -eq $live) { continue }
                Invoke-GoldsmithApply -Object $live -NewLine '' -ScopeKey $scopeKey -RemoveMode -Caller $PSCmdlet
            }
            finally { Set-Location $prev }
        }
    }
}

# ══════════════════════════════════════════════════════════════════════
#  Resolve a Get-GoldsmithTag result row back to a live SCCM object
#  (so Get-GoldsmithTag | Set/Remove-GoldsmithTag works end to end)
# ══════════════════════════════════════════════════════════════════════
function Resolve-GoldsmithRowToObject {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Row)

    # Only our own result rows have this exact shape
    if (-not ($Row.PSObject.Properties.Name -contains 'Item' -and $Row.PSObject.Properties.Name -contains 'Type' -and $Row.PSObject.Properties.Name -contains 'Metadata')) {
        return $Row   # not a row — pass through unchanged (already a live object)
    }

    switch ($Row.Type) {
        'Application' {
            $parts = $Row.Item -split ' :: ', 2
            $dt = Get-CMDeploymentType -ApplicationName $parts[0] -DeploymentTypeName $parts[1] -ErrorAction SilentlyContinue
            if ($dt) { return $dt }
        }
        'Package' {
            $parts = $Row.Item -split ' :: ', 2
            $prog = Get-CMProgram -PackageName $parts[0] -ProgramName $parts[1] -ErrorAction SilentlyContinue
            if ($prog) { return $prog }
        }
        'Script' {
            $scr = Get-CMScript -ScriptName $Row.Item -ErrorAction SilentlyContinue
            if ($scr) { return $scr }
        }
    }
    Write-Warning "Could not resolve '$($Row.Item)' back to a live SCCM object."
    return $null
}

# ══════════════════════════════════════════════════════════════════════
#  PUBLIC: Invoke-GoldsmithTagger — rich interactive front-end (humans)
# ══════════════════════════════════════════════════════════════════════
function Invoke-GoldsmithTagger {
    <#
    .SYNOPSIS
        Guided, menu-driven tagging for humans. Wraps the cmdlets.
    .DESCRIPTION
        Walks you through: pick item type → pick items (Out-GridView) →
        choose tag values (guided prompts) → confirm. Uses the same
        validated cmdlets underneath, so anything tagged here is
        build-ready. For scripting/automation use the cmdlets directly.
    .PARAMETER GoldsmithOnly
        When picking Applications, show only those already in the
        Goldsmith category (default $true — the short relevant list).
        Use -GoldsmithOnly:$false to browse the whole catalogue.
    .EXAMPLE
        Invoke-GoldsmithTagger
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [bool]$GoldsmithOnly = $true,
        [string]$ConfigPath
    )

    Import-GoldsmithConfig -ConfigPath $ConfigPath
    Initialize-GoldsmithConfigMgr
    $hasGrid = [bool](Get-Command Out-GridView -ErrorAction SilentlyContinue)

    function Read-GridOrList {
        param($Items, [string[]]$Display, [string]$Title)
        if (-not $Items -or @($Items).Count -eq 0) { return @() }
        if ($hasGrid) {
            return @($Items | Select-Object $Display | Out-GridView -Title $Title -OutputMode Multiple |
                     ForEach-Object { $sel = $_; $Items | Where-Object { $_.($Display[0]) -eq $sel.($Display[0]) } | Select-Object -First 1 })
        }
        Write-Host "`n$Title" -ForegroundColor Cyan
        $arr = @($Items)
        for ($i = 0; $i -lt $arr.Count; $i++) {
            $lbl = ($Display | ForEach-Object { '{0}=[{1}]' -f $_, $arr[$i].$_ }) -join '  '
            Write-Host ('[{0}] {1}' -f $i, $lbl)
        }
        $sel = Read-Host 'Enter indexes (comma-separated)'
        $idx = $sel -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
        return @($idx | Where-Object { $_ -ge 0 -and $_ -lt $arr.Count } | ForEach-Object { $arr[$_] })
    }

    function Read-Choice {
        param([string]$Prompt, [string[]]$Valid, [string]$Default)
        while ($true) {
            $v = Read-Host ("{0} [{1}] (default {2})" -f $Prompt, ($Valid -join '/'), $Default)
            if (Test-GoldsmithBlank $v) { return $Default }
            $v = $v.Trim().ToUpper()
            if ($v -in $Valid) { return $v }
            Write-Host "  Must be one of: $($Valid -join ', ')" -ForegroundColor Yellow
        }
    }

    $prev = (Get-Location).Path
    try {
        Set-Location ("{0}:\" -f $script:GoldsmithConfig.SiteCode)

        # ── 1. Item type ───────────────────────────────────────────────
        $type = Read-Choice -Prompt 'What are you tagging?' -Valid @('APPLICATION','PACKAGE','SCRIPT') -Default 'APPLICATION'

        # ── 2. Select the execution units ──────────────────────────────
        $targets = @()
        switch ($type) {
            'APPLICATION' {
                $apps = @(Get-CMApplication -Fast | Sort-Object LocalizedDisplayName)
                if ($GoldsmithOnly) {
                    $cat = $script:GoldsmithConfig.CategoryName
                    $filtered = @($apps | Where-Object {
                        $_.PSObject.Properties.Name -contains 'LocalizedCategoryInstanceNames' -and
                        $_.LocalizedCategoryInstanceNames -contains $cat
                    })
                    if ($filtered.Count -gt 0) { $apps = $filtered }
                    else { Write-Host "No apps in the '$cat' category yet — showing all." -ForegroundColor DarkGray }
                }
                $rows = $apps | ForEach-Object { [pscustomobject]@{ Application = $_.LocalizedDisplayName; Source = $_ } }
                $pickedApps = Read-GridOrList -Items $rows -Display @('Application') -Title 'Select Application(s)'
                foreach ($pa in $pickedApps) {
                    $dts = @(Get-CMDeploymentType -ApplicationName $pa.Application | Sort-Object LocalizedDisplayName)
                    $dtRows = $dts | ForEach-Object {
                        [pscustomobject]@{
                            Application = $pa.Application
                            DeploymentType = $_.LocalizedDisplayName
                            CurrentTags = ConvertTo-GoldsmithPreview (Get-GoldsmithDeploymentTypeComment -DeploymentType $_)
                            Source = $_
                        }
                    }
                    $picked = Read-GridOrList -Items $dtRows -Display @('Application','DeploymentType','CurrentTags') -Title "Deployment Types for [$($pa.Application)]"
                    $targets += $picked | ForEach-Object { $_.Source }
                }
            }
            'PACKAGE' {
                $pkgs = @(Get-CMPackage -Fast | Sort-Object Name)
                $rows = $pkgs | ForEach-Object { [pscustomobject]@{ Package = $_.Name; PackageID = $_.PackageID; Source = $_ } }
                $pickedPkgs = Read-GridOrList -Items $rows -Display @('Package','PackageID') -Title 'Select Package(s)'
                foreach ($pp in $pickedPkgs) {
                    $progs = @(Get-CMProgram -PackageId $pp.PackageID | Sort-Object ProgramName)
                    $prRows = $progs | ForEach-Object {
                        [pscustomobject]@{
                            Package = $pp.Package; Program = $_.ProgramName
                            CurrentTags = ConvertTo-GoldsmithPreview (Get-GoldsmithProgramComment -Program $_)
                            Source = $_
                        }
                    }
                    $picked = Read-GridOrList -Items $prRows -Display @('Package','Program','CurrentTags') -Title "Programs for [$($pp.Package)]"
                    $targets += $picked | ForEach-Object { $_.Source }
                }
            }
            'SCRIPT' {
                $scripts = @(Get-CMScript | Sort-Object ScriptName)
                $rows = $scripts | ForEach-Object {
                    [pscustomobject]@{
                        Script = $_.ScriptName
                        CurrentTags = ConvertTo-GoldsmithPreview (Get-GoldsmithScriptComment -ScriptObject $_)
                        Source = $_
                    }
                }
                $picked = Read-GridOrList -Items $rows -Display @('Script','CurrentTags') -Title 'Select Script(s)'
                $targets += $picked | ForEach-Object { $_.Source }
            }
        }

        if (-not $targets -or @($targets).Count -eq 0) {
            Write-Host 'Nothing selected. Done.' -ForegroundColor Yellow
            return
        }
        Write-Host ("`nSelected {0} item(s) to tag." -f @($targets).Count) -ForegroundColor Green

        # ── 3. Tag values ──────────────────────────────────────────────
        $target = (Read-Host 'Target (PV/PS/PD/PL/PX) [default PX]'); if (Test-GoldsmithBlank $target) { $target = 'PX' }
        $ring   = (Read-Host 'Ring (CORE/STD/DEV) [default CORE]');   if (Test-GoldsmithBlank $ring)   { $ring = 'CORE' }
        $order  = $null
        while ($true) {
            $order = Read-Host 'Order (00-99)'
            if ($order -match '^\d{1,2}$') { break }
            Write-Host '  Order must be 1-2 digits.' -ForegroundColor Yellow
        }
        $reboot = Read-Choice -Prompt 'Reboot' -Valid $script:ValidReboot -Default 'NR'
        $pause  = Read-Choice -Prompt 'Pause'  -Valid $script:ValidPause  -Default 'NP'
        $ov     = Read-Host 'OverrideValue (optional, blank for production)'
        $autostep = (Read-Host 'Auto-increment order across the selected items? (y/N)') -match '^(y|yes)$'

        # ── 4. Confirm + apply via the real cmdlet ─────────────────────
        $line = New-GoldsmithMetadataLine -Target $target -Ring $ring -Order $order -Reboot $reboot -Pause $pause -OverrideValue $ov
        Write-Host "`nAbout to apply:  $line" -ForegroundColor Cyan
        Write-Host "  to $(@($targets).Count) item(s), category upkeep automatic." -ForegroundColor DarkGray
        if ((Read-Host 'Proceed? (Y/n)') -match '^(n|no)$') { Write-Host 'Cancelled.' -ForegroundColor Yellow; return }

        $curOrder = [int]$order
        $results = foreach ($t in $targets) {
            $setParams = @{
                Target = $target; Ring = $ring; Order = ('{0:D2}' -f $curOrder)
                Reboot = $reboot; Pause = $pause
            }
            if (-not (Test-GoldsmithBlank $ov)) { $setParams.OverrideValue = $ov }
            $t | Set-GoldsmithTag @setParams
            if ($autostep) { $curOrder++; if ($curOrder -gt 99) { $curOrder = 99 } }
        }
        Write-Host ''
        $results | Format-Table Item, Type, Action, Metadata -AutoSize
        Write-Host 'Done.' -ForegroundColor Green
    }
    finally { Set-Location $prev }
}

# ══════════════════════════════════════════════════════════════════════
#  Exports
# ══════════════════════════════════════════════════════════════════════
Import-GoldsmithConfig
Export-ModuleMember -Function Get-GoldsmithTag, Set-GoldsmithTag, Remove-GoldsmithTag, Invoke-GoldsmithTagger
