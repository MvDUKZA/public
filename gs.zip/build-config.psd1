<#
    build-config.psd1  —  Goldsmith environment configuration
    ─────────────────────────────────────────────────────────────────
    EVERY environment-specific value lives here and nowhere else.
    Each setting below says where to find the real value.
    Different environment (test/prod, second site)? Copy this file and
    pass it with:  -ConfigPath .\config\build-config.prod.psd1
    (every Goldsmith script accepts -ConfigPath)
#>
@{

    # ── SCCM AdminService ────────────────────────────────────────────
    AdminService = @{
        # WHERE: your SMS Provider machine FQDN — in the ConfigMgr
        # console: Administration → Site Configuration → Sites →
        # (site) → Properties → General shows the site server; the SMS
        # Provider is listed under Monitoring → System Status, or ask
        # the SCCM team. Usually the primary site server itself.
        # TEST:  open https://<fqdn>/AdminService/wmi/SMS_Site in a
        # browser on the jump box — you should get JSON back.
        BaseUrl               = 'https://appsmcm101fp.iprod.local/AdminService'   # SMS Provider (site PRD)
        UseDefaultCredentials = $true
    }

    # ── SCCM identity (used by the Goldsmith.Tagging module) ─────────
    # SMS Provider FQDN and site code. Confirmed from AdminService:
    #   SMS_Site → SiteCode "PRD", ServerName appsmcm101fp.iprod.local
    SccmProvider      = 'appsmcm101fp.iprod.local'
    SccmSiteCode      = 'PRD'
    GoldsmithCategory = 'Goldsmith'

    # ── Metadata field mapping ───────────────────────────────────────
    # Verify with ONE tagged test item + -DryRun before first build.
    MetadataFields = @{
        PackageProgram        = 'Comment'       # SMS_Program property
        ApplicationDeployType = 'Description'   # DT node in SDMPackageXML
        Script                = 'Comment'       # SMS_Scripts property
    }

    # ── OS library ───────────────────────────────────────────────────
    OSLibrary = @{
        # WHERE: the file share you created for extracted OS folders
        SharePath        = '\\server\OS'                                      # ← CHANGE
        # NOTE: the datastore ISO path is per-vCenter — see VCenters below.
    }

    # ── Ring model (order = build chain = sort order) ────────────────
    Rings = @('CORE', 'STD', 'DEV')

    # ── Pause duration for PB/PA metadata flags (seconds) ────────────
    PauseSeconds = 60

    # ── vCenters ─────────────────────────────────────────────────────
    # One named block per vCenter. Select at build time with
    #   -VCenter LON        (any Goldsmith script)
    # or omit the flag to use DefaultVCenter.
    # WHERE: all values visible in that vCenter's vSphere Client
    # inventory. Names must match EXACTLY — Packer resolves by name.
    DefaultVCenter = 'LON'

    VCenters = @{

        LON = @{
            Server           = 'vcenter-lon.contoso.local'  # ← CHANGE  vCenter FQDN
            Datacenter       = 'DC-LON'                     # ← CHANGE
            Cluster          = 'LON-Compute-1'              # ← CHANGE
            Datastore        = 'LON-Datastore-VM'           # ← CHANGE  build VMs land here
            Folder           = 'GoldsmithBuilds'            #   VM folder for in-progress builds
            Network          = 'VM Network'                 # ← CHANGE  must reach SCCM share
                                                            #   + WinRM 5985 from jump box
            TemplateFolder   = 'Templates/Golden'           #   finished templates live here
            # Serviced ISOs for THIS vCenter — Packer iso_paths syntax:
            # "[DatastoreName] folder"
            DatastoreIsoPath = '[LON-Datastore-ISO] packer' # ← CHANGE
        }

        # Add more as needed — same shape:
        # NYC = @{
        #     Server           = 'vcenter-nyc.contoso.local'
        #     Datacenter       = 'DC-NYC'
        #     Cluster          = 'NYC-Compute-1'
        #     Datastore        = 'NYC-Datastore-VM'
        #     Folder           = 'GoldsmithBuilds'
        #     Network          = 'VM Network'
        #     TemplateFolder   = 'Templates/Golden'
        #     DatastoreIsoPath = '[NYC-Datastore-ISO] packer'
        # }
    }

    # ── SCCM content share (inside build VMs) ────────────────────────
    # Env var NAMES only — values are prompted daily by
    # Initialize-GoldsmithSession.ps1 and never stored.
    ContentShare = @{
        UsernameEnvVar = 'PKR_SCCM_SHARE_USER'
        PasswordEnvVar = 'PKR_SCCM_SHARE_PASS'
    }

    # ── Paths (relative to the Goldsmith folder) ─────────────────────
    Paths = @{
        Templates = 'templates'
        Output    = 'output'
    }

    # ── Packer ───────────────────────────────────────────────────────
    Packer = @{
        Executable = 'packer'    # full path if not on PATH
    }
}
