# Goldsmith — Quick User Guide

*For build engineers. Five minutes to read, covers 95% of what you'll do.*

---

## What this does

One command turns a serviced Windows ISO plus SCCM-tagged software into
three vSphere templates: **CORE** (OS + essentials), **STD** (CORE +
standard apps), **DEV** (STD + dev tools). SCCM is the only place
software is defined. Nothing is installed twice.

---

## Start of every build day (passwords rotate daily)

1. Log on to the jump box with your own domain account. SCCM queries
   run as you automatically — no setup needed.

2. In the console you'll build from, run:

   ```powershell
   .\Initialize-GoldsmithSession.ps1 -Validate
   ```

   It prompts for three things — your vCenter login, the read-only
   share service account (`CONTOSO\svc-packer-read`, password from the
   vault), and the build VM Administrator password — then tests that
   SCCM, the share, and vCenter all answer.

   Nothing is saved anywhere: the credentials live only inside that
   console window and vanish when it closes. New window or new day =
   run it again.

---

## Tagging software in SCCM

Put ONE metadata line in the comment field of the thing you want in the
image:

| SCCM object | Field |
|---|---|
| Application → Deployment Type | Administrator comments |
| Package → Program | Comment |
| Script | Description |

**Format:** `Target|Ring|Order|Reboot|Pause` (add `|YourName` for a
personal test line)

| Token | Values | Meaning |
|---|---|---|
| Target | `PV` `PS` `PD` `PL` `PX` | VDI / Server / Desktop / Laptop / everything |
| Ring | `CORE` `STD` `DEV` | which image layer |
| Order | `00`–`99` | lower runs first within the ring |
| Reboot | `NR` `RB` `RA` | none / reboot before / reboot after |
| Pause | `NP` `PB` `PA` | none / pause before / pause after |

**Examples**

```
PX|CORE|10|NR|NP           everywhere, early in CORE
PV|CORE|12|NR|NP           VDI only — silently replaces a PX line on the same item
PS|STD|30|RA|NP            servers, STD ring, reboot after install
PV|CORE|20|NR|NP|Marinus   Marinus' test version — ignored unless he asks for it
```

Rules of thumb: no metadata = not in the image. A specific target beats
`PX` on the same item. Reboots never happen unless you say `RB`/`RA`.

---

## Monthly cycle (after Patch Tuesday)

**1. Service the ISO** (creates the dated folder + bootable ISO):

```powershell
.\Invoke-GoldsmithServicing.ps1 -BaseFolder Win11_Enterprise_24H2 `
    -CuPath \\server\Updates\2026-07\windows11-kb50xxxxx-x64.msu
```

If Microsoft shipped a separate SSU that month, add `-SsuPath <path>` —
the script applies it first, as required.

**2. Upload the ISO to the datastore:**

```powershell
Connect-VIServer vcenter.contoso.local
Copy-DatastoreItem '\\server\OS\Win11_Enterprise_24H2_0726.iso' `
    -Destination (Get-Datastore 'Datastore-ISO').DatastoreBrowserPath + '\packer\'
```

**3. Preview the build** — always do this first:

```powershell
.\Invoke-GoldsmithGenerator.ps1 -OSFolder Win11_Enterprise_24H2_0726 -Target PV -DryRun
```

You get a table of every item, in install order, per ring. If the list
looks wrong, fix the metadata in SCCM and re-run. Nothing was written.

**4. Build:**

```powershell
.\Start-GoldsmithBuild.ps1 -OSFolder Win11_Enterprise_24H2_0726 -Target PV
```

Walk away. CORE takes the longest (full OS install); STD and DEV are
quick clones. You end up with three templates:

```
Win11_Enterprise_24H2_0726_PV_CORE
Win11_Enterprise_24H2_0726_PV_STD
Win11_Enterprise_24H2_0726_PV_DEV
```

---

## Common tasks

**Test your own package version without touching production:**
add a 6-token line (`PV|CORE|20|NR|NP|YourName`) next to the default,
then:

```powershell
.\Start-GoldsmithBuild.ps1 -OSFolder <folder> -Target PV -OverrideValue YourName
```

Production builds ignore your line completely.

**A ring failed — resume without redoing the earlier rings:**

```powershell
.\Start-GoldsmithBuild.ps1 -OSFolder <folder> -Target PV -SkipGenerate -StartFromRing DEV
```

**Build for a different platform:** same command, different `-Target`
(`PS`, `PD`, `PL`). `PX`-tagged items are included in all of them.

---

## When generation fails

That's it doing its job — it refuses to build a wrong image. The error
names the exact SCCM item and the problem, e.g.:

```
VALIDATION [Corporate Baseline :: Apply Baseline] Reboot 'YES' not one of NR, RB, RA
```

Fix the metadata line in SCCM, re-run. All errors are reported in one
pass, so fix everything it lists, not just the first one.

Common causes: typo in a token · non-numeric Order · two identical
override lines on one item · two default lines for the same ring on one
item · a Ring name that isn't CORE/STD/DEV.

---

## Where things live

| What | Where |
|---|---|
| Build scripts | `C:\Goldsmith\` on the jump box |
| OS library | `\\server\OS\` |
| Generated files (audit) | `C:\Goldsmith\output\` + `generation-manifest.json` |
| Build logs + manifests | `C:\Goldsmith\logs\` |
| Templates produced | vSphere → `Templates/Golden` folder |
