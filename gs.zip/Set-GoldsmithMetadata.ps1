<#
.SYNOPSIS
    Set, remove, or audit Goldsmith (Packer) metadata on SCCM
    Deployment Types, Programs, and Scripts.

.DESCRIPTION
    Updates the SCCM free-text fields the Goldsmith generator reads.
    SCCM stays the single source of truth; this tool just makes the
    metadata safe and easy to maintain — no hand-typing in the console.

    Metadata schema:
        <Target>|<Ring>|<Order>|<Reboot>|<Pause>[|<OverrideValue>]

    Examples:
        PX|CORE|10|NR|NP
        PV|STD|30|NR|NP|Marinus

    Three modes:
      • WRITE (default) — pick items interactively (Out-GridView or a
        numbered console list) or pipe them in, then add/replace the tag.
      • REMOVE (-Remove) — strip the tag matching Target+Ring(+Override).
      • AUDIT (-List)   — read-only report of every tagged item, fast,
        via the AdminService (no console module needed).

    Behaviour:
      - Application Deployment Type -> AdministratorComment
      - Package Program            -> Comment
      - Script                     -> SMS Provider Comment/Description
      - Applications and Packages are selection containers only;
        metadata is written to Deployment Types, Programs, and Scripts.

.NOTES
    Author:  Marinus van Deventer   (audit mode + scope/validation
             refinements folded in)
    Requires:
      - PowerShell 5.1+
      - ConfigMgr console / module (for WRITE/REMOVE)
      - Run from a machine with access to the site server and SMS Provider

.PARAMETER SiteCode
    ConfigMgr site code. Default read from build-config.psd1 if present.

.PARAMETER ProviderMachineName
    SMS Provider FQDN. Default read from build-config.psd1 if present.

.PARAMETER InputObject
    Pipeline input — Deployment Type, Program, or Script objects.

.PARAMETER ItemType
    Application | Package | Script. Prompted if omitted in interactive mode.

.PARAMETER Target / Ring / Order / Reboot / Pause / OverrideValue
    Metadata tokens. Missing ones are prompted in interactive mode.

.PARAMETER AutoIncrementOrder
    After each item, bump Order by 1 for the next (batch tagging).

.PARAMETER Remove
    Remove the tag matching Target+Ring(+OverrideValue) instead of adding.

.PARAMETER Force
    Replace an existing same-scope tag without prompting.

.PARAMETER UseGui
    Use Out-GridView pickers when available (else numbered console list).

.PARAMETER List
    AUDIT mode: list every Goldsmith-tagged item and exit. Read-only.

.EXAMPLE
    # Interactive tag for VDI CORE, order 20:
    .\Set-GoldsmithMetadata.ps1 -Target PV -Ring CORE -Order 20 -UseGui

.EXAMPLE
    # Batch-tag several items, auto-stepping the order:
    .\Set-GoldsmithMetadata.ps1 -Target PX -Ring STD -Order 10 -AutoIncrementOrder

.EXAMPLE
    # Audit everything currently tagged:
    .\Set-GoldsmithMetadata.ps1 -List
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium', DefaultParameterSetName = 'Write')]
param(
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$SiteCode,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$ProviderMachineName,

    [Parameter(ValueFromPipeline = $true, ParameterSetName = 'Write')]
    [object]$InputObject,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidateSet('Application', 'Package', 'Script')]
    [string]$ItemType,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidateNotNullOrEmpty()]
    [string]$Target,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidateNotNullOrEmpty()]
    [string]$Ring,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidatePattern('^\d{2}$')]
    [string]$Order,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [switch]$AutoIncrementOrder,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidateSet('NR', 'RB', 'RA')]
    [string]$Reboot,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [ValidateSet('NP', 'PB', 'PA')]
    [string]$Pause,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [string]$OverrideValue,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [switch]$Remove,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [switch]$Force,

    [Parameter(Mandatory = $false, ParameterSetName = 'Write')]
    [switch]$UseGui,

    [Parameter(Mandatory = $true, ParameterSetName = 'List')]
    [switch]$List,

    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config\build-config.psd1')
)

begin {
    Set-StrictMode -Version Latest
    $ErrorActionPreference = 'Stop'

    $pipelineItems = [System.Collections.Generic.List[object]]::new()

    # ── Canonical metadata regex (named groups, exactly-two-digit Order) ──
    $script:metadataRegex = '^(?<Target>[^|\r\n]+)\|(?<Ring>[^|\r\n]+)\|(?<Order>\d{2})\|(?<Reboot>NR|RB|RA)\|(?<Pause>NP|PB|PA)(?:\|(?<Override>[^|\r\n]+))?$'

    # ── Optional config for defaults (SiteCode / Provider / field names) ──
    $script:config = $null
    if (Test-Path $ConfigPath) {
        try { $script:config = Import-PowerShellDataFile -Path $ConfigPath } catch { $script:config = $null }
    }
    if (-not $SiteCode -and $script:config -and $script:config.ContainsKey('SccmSiteCode')) {
        $SiteCode = $script:config.SccmSiteCode
    }
    if (-not $ProviderMachineName -and $script:config -and $script:config.ContainsKey('SccmProvider')) {
        $ProviderMachineName = $script:config.SccmProvider
    }
    if (-not $SiteCode)            { $SiteCode = 'PRD' }
    if (-not $ProviderMachineName) { $ProviderMachineName = 'APPSMCM01FP.iprod.local' }

    #region Logging
    $currentFolder = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $logFolder = Join-Path -Path $currentFolder -ChildPath 'logs'
    if (-not (Test-Path -Path $logFolder)) {
        New-Item -Path $logFolder -ItemType Directory -Force | Out-Null
    }
    $timeStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $logPath = Join-Path -Path $logFolder -ChildPath "Set-GoldsmithMetadata_$timeStamp.log"

    function Write-Log {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][string]$Message,
            [Parameter(Mandatory = $false)][ValidateSet('INFO', 'WARN', 'ERROR')][string]$Level = 'INFO'
        )
        $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
        Add-Content -Path $logPath -Value $line
        Write-Host $line
    }
    #endregion

    function Test-IsBlank {
        [CmdletBinding()]
        param([AllowNull()][string]$Value)
        return [string]::IsNullOrWhiteSpace($Value)
    }

    # ══════════════════════════════════════════════════════════════════
    #  Metadata primitives
    # ══════════════════════════════════════════════════════════════════
    function New-MetadataLine {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][string]$Target,
            [Parameter(Mandatory = $true)][string]$Ring,
            [Parameter(Mandatory = $true)][string]$Order,
            [Parameter(Mandatory = $true)][ValidateSet('NR', 'RB', 'RA')][string]$Reboot,
            [Parameter(Mandatory = $true)][ValidateSet('NP', 'PB', 'PA')][string]$Pause,
            [Parameter(Mandatory = $false)][string]$OverrideValue
        )
        $baseLine = '{0}|{1}|{2}|{3}|{4}' -f $Target.Trim().ToUpper(), $Ring.Trim().ToUpper(), $Order, $Reboot, $Pause
        if (Test-IsBlank $OverrideValue) { return $baseLine }
        return '{0}|{1}' -f $baseLine, $OverrideValue.Trim()
    }

    function Test-IsMetadataLine {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)][string]$Line)
        return ($Line -match $script:metadataRegex)
    }

    function ConvertTo-MetadataPreview {
        [CmdletBinding()]
        param(
            [AllowNull()][string]$Text,
            [Parameter(Mandatory = $false)][int]$MaxLength = 120
        )
        if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
        $metadataLines = foreach ($line in ($Text -split "`r?`n")) {
            if ($line -match $script:metadataRegex) { $line.Trim() }
        }
        if (-not $metadataLines) { return '' }
        $preview = ($metadataLines -join '; ')
        if ($preview.Length -gt $MaxLength) { return $preview.Substring(0, $MaxLength - 3) + '...' }
        return $preview
    }

    # ══════════════════════════════════════════════════════════════════
    #  Merge — insert/replace one tag, keyed on Target + Ring + Override
    #  (Ring is part of the scope so one item can live in several rings)
    # ══════════════════════════════════════════════════════════════════
    function Merge-MetadataText {
        [CmdletBinding()]
        param(
            [AllowNull()][string]$CurrentText,
            [Parameter(Mandatory = $true)][string]$NewMetadataLine,
            [Parameter(Mandatory = $true)][string]$Target,
            [Parameter(Mandatory = $true)][string]$Ring,
            [Parameter(Mandatory = $false)][string]$OverrideValue,
            [Parameter(Mandatory = $false)][switch]$Force,
            [Parameter(Mandatory = $false)][switch]$RemoveOnly
        )
        $lines = if ([string]::IsNullOrWhiteSpace($CurrentText)) { @() } else { $CurrentText -split "`r?`n" }
        $metadataLines  = [System.Collections.Generic.List[string]]::new()
        $otherLines     = [System.Collections.Generic.List[string]]::new()
        $existingLine   = $null
        $compareTarget  = $Target.Trim().ToUpper()
        $compareRing    = $Ring.Trim().ToUpper()
        $compareOverride = if (Test-IsBlank $OverrideValue) { '' } else { $OverrideValue.Trim() }

        foreach ($line in $lines) {
            $trimmed = $line.TrimEnd()
            if (-not $trimmed) { continue }
            if (Test-IsMetadataLine -Line $trimmed) {
                $null = $trimmed -match $script:metadataRegex
                $lineTarget   = $Matches.Target.Trim().ToUpper()
                $lineRing     = $Matches.Ring.Trim().ToUpper()
                $lineOverride = if ($Matches.Override) { $Matches.Override.Trim() } else { '' }

                # Same scope = same Target AND Ring AND Override
                if ($lineTarget -eq $compareTarget -and $lineRing -eq $compareRing -and $lineOverride -eq $compareOverride) {
                    if (-not $existingLine) { $existingLine = $trimmed }
                    continue    # drop the old one; new one (if any) added below
                }
                $metadataLines.Add($trimmed) | Out-Null
            }
            else {
                $otherLines.Add($trimmed) | Out-Null
            }
        }

        # ── REMOVE: succeeds only if something was actually there ─────────
        if ($RemoveOnly) {
            $updated = (($metadataLines + $otherLines) -join [Environment]::NewLine).TrimEnd()
            return [pscustomobject]@{
                UpdatedText  = $updated
                Changed      = [bool]$existingLine
                ExistingLine = $existingLine
            }
        }

        # ── ADD/REPLACE: confirm replace unless -Force ────────────────────
        if ($existingLine -and -not $Force) {
            Write-Host ''
            Write-Host 'Existing metadata line found:'
            Write-Host "  $existingLine"
            Write-Host 'New metadata line:'
            Write-Host "  $NewMetadataLine"
            $answer = Read-Host 'Replace existing metadata line? [Y/N]'
            if ($answer -notmatch '^(Y|YES)$') {
                return [pscustomobject]@{
                    UpdatedText  = $CurrentText
                    Changed      = $false
                    ExistingLine = $existingLine
                }
            }
        }

        $newLines = [System.Collections.Generic.List[string]]::new()
        $newLines.Add($NewMetadataLine) | Out-Null
        foreach ($line in $metadataLines) { $newLines.Add($line) | Out-Null }
        foreach ($line in $otherLines)    { $newLines.Add($line) | Out-Null }

        $updatedText = ($newLines.ToArray() -join [Environment]::NewLine).TrimEnd()
        return [pscustomobject]@{
            UpdatedText  = $updatedText
            Changed      = ($existingLine -ne $NewMetadataLine -or $null -eq $existingLine)
            ExistingLine = $existingLine
        }
    }

    # ══════════════════════════════════════════════════════════════════
    #  Identity + comment read/write per object type
    # ══════════════════════════════════════════════════════════════════
    function Get-DeploymentTypeIdentity {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$DeploymentType)

        $dtName = if ($DeploymentType.PSObject.Properties.Name -contains 'LocalizedDisplayName' -and -not (Test-IsBlank $DeploymentType.LocalizedDisplayName)) {
            [string]$DeploymentType.LocalizedDisplayName
        }
        elseif ($DeploymentType.PSObject.Properties.Name -contains 'DeploymentTypeName' -and -not (Test-IsBlank $DeploymentType.DeploymentTypeName)) {
            [string]$DeploymentType.DeploymentTypeName
        }
        else { '' }

        $appName = ''
        if ($DeploymentType.PSObject.Properties.Name -contains 'ApplicationName' -and -not (Test-IsBlank $DeploymentType.ApplicationName)) {
            $appName = [string]$DeploymentType.ApplicationName
        }
        if (Test-IsBlank $appName) {
            try {
                $parentApp = Get-CMApplication -InputObject $DeploymentType -Fast -ErrorAction Stop
                if ($null -ne $parentApp -and $parentApp.PSObject.Properties.Name -contains 'LocalizedDisplayName') {
                    $appName = [string]$parentApp.LocalizedDisplayName
                }
            }
            catch {
                Write-Log -Message "Failed to resolve parent application for deployment type [$dtName]: $($_.Exception.Message)" -Level 'WARN'
            }
        }

        return [pscustomobject]@{
            ApplicationName    = $appName
            DeploymentTypeName = $dtName
        }
    }

    function Get-DeploymentTypeComment {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$DeploymentType)
        try {
            if ($DeploymentType.PSObject.Methods.Name -contains 'Get') { $DeploymentType.Get() }
        }
        catch {
            Write-Log -Message "Lazy-load Get() failed for deployment type [$($DeploymentType.LocalizedDisplayName)]: $($_.Exception.Message)" -Level 'WARN'
        }
        foreach ($propertyName in 'AdministratorComment', 'AdminComment') {
            if ($DeploymentType.PSObject.Properties.Name -contains $propertyName) {
                return [string]$DeploymentType.$propertyName
            }
        }
        return [string]::Empty
    }

    function Set-DeploymentTypeComment {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)]$DeploymentType,
            [Parameter(Mandatory = $true)][string]$CommentText
        )
        $identity = Get-DeploymentTypeIdentity -DeploymentType $DeploymentType
        if (Test-IsBlank $identity.ApplicationName)    { throw 'Unable to resolve ApplicationName for Set-CMDeploymentType.' }
        if (Test-IsBlank $identity.DeploymentTypeName) { throw 'Unable to resolve DeploymentTypeName for Set-CMDeploymentType.' }
        Set-CMDeploymentType -ApplicationName $identity.ApplicationName -DeploymentTypeName $identity.DeploymentTypeName -AdministratorComment $CommentText -Confirm:$false | Out-Null
    }

    function Get-ProgramComment {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$Program)
        if ($Program.PSObject.Properties.Name -contains 'Comment') { return [string]$Program.Comment }
        return [string]::Empty
    }

    function Set-ProgramCommentByInputObject {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)]$Program,
            [Parameter(Mandatory = $true)][string]$CommentText
        )
        $packageId   = if ($Program.PSObject.Properties.Name -contains 'PackageID')   { [string]$Program.PackageID }   else { '' }
        $programName = if ($Program.PSObject.Properties.Name -contains 'ProgramName') { [string]$Program.ProgramName } else { '' }
        if (Test-IsBlank $packageId)   { throw 'Unable to resolve PackageID for Set-CMProgram.' }
        if (Test-IsBlank $programName) { throw 'Unable to resolve ProgramName for Set-CMProgram.' }

        # Preserve the program's existing kind (standard vs device) rather
        # than forcing -StandardProgram, which could reshape a device program.
        $isStandard = $true
        if ($Program.PSObject.Properties.Name -contains 'ProgramFlags') {
            # DeviceProgram bit — treat non-standard programs accordingly
            try { $isStandard = -not ([bool]($Program.ProgramFlags -band 0x00001000)) } catch { $isStandard = $true }
        }
        if ($isStandard) {
            Set-CMProgram -PackageId $packageId -ProgramName $programName -StandardProgram -Comment $CommentText -Confirm:$false | Out-Null
        }
        else {
            Set-CMProgram -PackageId $packageId -ProgramName $programName -Comment $CommentText -Confirm:$false | Out-Null
        }
    }

    function Get-SmsScriptRecord {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$ScriptObject)
        $namespace  = "root\SMS\site_$SiteCode"
        $scriptGuid = $null
        foreach ($propertyName in 'ScriptGuid', 'Guid') {
            if ($ScriptObject.PSObject.Properties.Name -contains $propertyName -and -not (Test-IsBlank $ScriptObject.$propertyName)) {
                $scriptGuid = [string]$ScriptObject.$propertyName
                break
            }
        }
        if (-not (Test-IsBlank $scriptGuid)) {
            try {
                return Get-CimInstance -ComputerName $ProviderMachineName -Namespace $namespace -ClassName SMS_Scripts -Filter ("ScriptGuid='{0}'" -f $scriptGuid) -ErrorAction Stop
            }
            catch {
                Write-Log -Message "Lookup by ScriptGuid [$scriptGuid] failed: $($_.Exception.Message)" -Level 'WARN'
            }
        }
        if ($ScriptObject.PSObject.Properties.Name -contains 'ScriptName' -and -not (Test-IsBlank $ScriptObject.ScriptName)) {
            $escapedName = $ScriptObject.ScriptName.Replace("'", "''")
            return Get-CimInstance -ComputerName $ProviderMachineName -Namespace $namespace -ClassName SMS_Scripts -Filter ("ScriptName='{0}'" -f $escapedName) -ErrorAction Stop
        }
        throw 'Unable to resolve SMS_Scripts record.'
    }

    function Get-ScriptComment {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$ScriptObject)
        $scriptRecord = Get-SmsScriptRecord -ScriptObject $ScriptObject
        foreach ($propertyName in 'Comment', 'Description') {
            if ($scriptRecord.PSObject.Properties.Name -contains $propertyName) {
                return [string]$scriptRecord.$propertyName
            }
        }
        return [string]::Empty
    }

    function Set-ScriptComment {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)]$ScriptObject,
            [Parameter(Mandatory = $true)][string]$CommentText
        )
        $scriptRecord = Get-SmsScriptRecord -ScriptObject $ScriptObject
        $propertyName = if ($scriptRecord.PSObject.Properties.Name -contains 'Comment') { 'Comment' } else { 'Description' }
        $scriptRecord.$propertyName = $CommentText
        Set-CimInstance -InputObject $scriptRecord -ErrorAction Stop | Out-Null
        # NOTE: if your site enforces script approval, re-approve after tagging.
    }

    # ══════════════════════════════════════════════════════════════════
    #  Input classification + selection-row builders
    # ══════════════════════════════════════════════════════════════════
    function Resolve-InputType {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$Object)
        $properties = @($Object.PSObject.Properties.Name)
        if ($properties -contains 'ScriptName') { return 'Script' }
        if ($properties -contains 'ProgramName' -and ($properties -contains 'PackageID' -or $properties -contains 'PackageId')) { return 'Program' }
        if (($properties -contains 'LocalizedDisplayName' -or $properties -contains 'DeploymentTypeName') -and -not ($properties -contains 'ScriptName')) { return 'DeploymentType' }
        return 'Unknown'
    }

    function New-ApplicationSelectionRow {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$Application)
        [pscustomobject]@{
            ApplicationName = $Application.LocalizedDisplayName
            SourceObject    = $Application
        }
    }

    function New-DeploymentTypeSelectionRow {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][string]$ApplicationName,
            [Parameter(Mandatory = $true)]$DeploymentType
        )
        [pscustomobject]@{
            ApplicationName = $ApplicationName
            DeploymentType  = (Get-DeploymentTypeIdentity -DeploymentType $DeploymentType).DeploymentTypeName
            CurrentMetadata = (ConvertTo-MetadataPreview -Text (Get-DeploymentTypeComment -DeploymentType $DeploymentType))
            SourceObject    = $DeploymentType
        }
    }

    function New-PackageSelectionRow {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$Package)
        [pscustomobject]@{
            PackageName  = $Package.Name
            PackageId    = $Package.PackageID
            SourceObject = $Package
        }
    }

    function New-ProgramSelectionRow {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][string]$PackageName,
            [Parameter(Mandatory = $true)]$Program
        )
        [pscustomobject]@{
            PackageName     = $PackageName
            ProgramName     = $Program.ProgramName
            CurrentMetadata = (ConvertTo-MetadataPreview -Text (Get-ProgramComment -Program $Program))
            SourceObject    = $Program
        }
    }

    function New-ScriptSelectionRow {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)]$Script)
        [pscustomobject]@{
            ScriptName      = $Script.ScriptName
            CurrentMetadata = (ConvertTo-MetadataPreview -Text (Get-ScriptComment -ScriptObject $Script))
            SourceObject    = $Script
        }
    }

    # ══════════════════════════════════════════════════════════════════
    #  Selection UI — Out-GridView when asked & available, else console
    # ══════════════════════════════════════════════════════════════════
    function Get-SelectorMode {
        [CmdletBinding()]
        param()
        if ($UseGui -and (Get-Command -Name Out-GridView -ErrorAction SilentlyContinue)) { return 'Gui' }
        return 'Console'
    }

    function Select-Items {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][object[]]$Items,
            [Parameter(Mandatory = $true)][string[]]$DisplayProperties,
            [Parameter(Mandatory = $true)][string]$Prompt
        )
        if (-not $Items -or $Items.Count -eq 0) { return @() }
        $visibleProperties = @($DisplayProperties | Where-Object { $_ -ne 'SourceObject' })
        $selectorMode = Get-SelectorMode

        if ($selectorMode -eq 'Gui') {
            $displayItems = @($Items | Select-Object -Property $visibleProperties)
            $selected = @($displayItems | Out-GridView -Title $Prompt -PassThru)

            $results = [System.Collections.Generic.List[object]]::new()
            foreach ($selectedItem in $selected) {
                $match = $null
                foreach ($candidate in $Items) {
                    $isMatch = $true
                    foreach ($propertyName in $visibleProperties) {
                        $candidateValue = if ($candidate.PSObject.Properties.Name -contains $propertyName) { [string]$candidate.$propertyName } else { '' }
                        $selectedValue  = if ($selectedItem.PSObject.Properties.Name -contains $propertyName) { [string]$selectedItem.$propertyName } else { '' }
                        if ($candidateValue -ne $selectedValue) { $isMatch = $false; break }
                    }
                    if ($isMatch) { $match = $candidate; break }
                }
                if ($null -ne $match -and $match.PSObject.Properties.Name -contains 'SourceObject') {
                    $results.Add($match.SourceObject) | Out-Null
                }
            }
            return @($results)
        }

        Write-Host ''
        Write-Host $Prompt
        for ($index = 0; $index -lt $Items.Count; $index++) {
            $item = $Items[$index]
            $line = $visibleProperties | ForEach-Object { '{0}=[{1}]' -f $_, $item.$_ }
            Write-Host ('[{0}] {1}' -f $index, ($line -join '  '))
        }

        $selection = Read-Host 'Enter one or more indexes separated by comma'
        if (Test-IsBlank $selection) { return @() }

        $indexes = $selection -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
        $results = foreach ($index in $indexes) {
            if ($index -ge 0 -and $index -lt $Items.Count) { $Items[$index].SourceObject }
        }
        return @($results)
    }

    function Get-InteractiveTargets {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)][ValidateSet('Application', 'Package', 'Script')][string]$ItemType)

        switch ($ItemType) {
            'Application' {
                Write-Log -Message 'Building Application selection list.' -Level 'INFO'
                $applications = @(Get-CMApplication -Fast | Sort-Object LocalizedDisplayName)
                $applicationRows = foreach ($application in $applications) { New-ApplicationSelectionRow -Application $application }

                $selectedApps = @(Select-Items -Items $applicationRows -DisplayProperties @('ApplicationName') -Prompt 'Select one or more Applications')
                $results = [System.Collections.Generic.List[object]]::new()
                foreach ($app in $selectedApps) {
                    $appName = $app.LocalizedDisplayName
                    Write-Log -Message "Loading Deployment Types for application [$appName]" -Level 'INFO'
                    $deploymentTypes = @(Get-CMDeploymentType -ApplicationName $appName | Sort-Object LocalizedDisplayName)
                    $deploymentTypeRows = foreach ($deploymentType in $deploymentTypes) { New-DeploymentTypeSelectionRow -ApplicationName $appName -DeploymentType $deploymentType }
                    $selectedDts = @(Select-Items -Items $deploymentTypeRows -DisplayProperties @('ApplicationName', 'DeploymentType', 'CurrentMetadata') -Prompt "Select Deployment Types for [$appName]")
                    foreach ($dt in $selectedDts) { $results.Add($dt) | Out-Null }
                }
                return @($results)
            }
            'Package' {
                Write-Log -Message 'Building Package selection list.' -Level 'INFO'
                $packages = @(Get-CMPackage -Fast | Sort-Object Name)
                $packageRows = foreach ($package in $packages) { New-PackageSelectionRow -Package $package }

                $selectedPackages = @(Select-Items -Items $packageRows -DisplayProperties @('PackageName', 'PackageId') -Prompt 'Select one or more Packages')
                $results = [System.Collections.Generic.List[object]]::new()
                foreach ($package in $selectedPackages) {
                    Write-Log -Message "Loading Programs for package [$($package.Name)]" -Level 'INFO'
                    $programs = @(Get-CMProgram -PackageId $package.PackageID | Sort-Object ProgramName)
                    $programRows = foreach ($program in $programs) { New-ProgramSelectionRow -PackageName $package.Name -Program $program }
                    $selectedPrograms = @(Select-Items -Items $programRows -DisplayProperties @('PackageName', 'ProgramName', 'CurrentMetadata') -Prompt "Select Programs for [$($package.Name)]")
                    foreach ($program in $selectedPrograms) { $results.Add($program) | Out-Null }
                }
                return @($results)
            }
            'Script' {
                Write-Log -Message 'Building Script selection list.' -Level 'INFO'
                $scripts = @(Get-CMScript -Fast | Sort-Object ScriptName)
                $scriptRows = foreach ($script in $scripts) { New-ScriptSelectionRow -Script $script }
                return @(Select-Items -Items $scriptRows -DisplayProperties @('ScriptName', 'CurrentMetadata') -Prompt 'Select one or more Scripts')
            }
        }
    }

    function Step-OrderValue {
        [CmdletBinding()]
        param([Parameter(Mandatory = $true)][string]$CurrentOrder)
        $next = [int]$CurrentOrder + 1
        if ($next -gt 99) { throw 'AutoIncrementOrder exceeded 99.' }
        return ('{0:D2}' -f $next)
    }

    function Read-ChoiceValue {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory = $true)][string]$Prompt,
            [Parameter(Mandatory = $false)][string]$DefaultValue
        )
        $message = if (Test-IsBlank $DefaultValue) { $Prompt } else { "$Prompt (default: $DefaultValue)" }
        $value = Read-Host $message
        if (Test-IsBlank $value) { return $DefaultValue }
        return $value.Trim()
    }

    function Read-OrderValue {
        [CmdletBinding()]
        param([Parameter(Mandatory = $false)][string]$DefaultValue = '00')
        while ($true) {
            $value = Read-ChoiceValue -Prompt 'Order (00-99)' -DefaultValue $DefaultValue
            if ($value -match '^\d{2}$') { return $value }
            Write-Log -Message 'Order must be exactly two digits, for example 05 or 30.' -Level 'WARN'
        }
    }

    function Initialize-ConfigMgrContext {
        [CmdletBinding()]
        param()
        if (-not (Get-Module -ListAvailable -Name ConfigurationManager -ErrorAction SilentlyContinue)) {
            if (-not $env:SMS_ADMIN_UI_PATH) {
                throw 'ConfigurationManager module not found. Install the ConfigMgr console on this machine.'
            }
            Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1') -ErrorAction Stop
        }
        else {
            Import-Module ConfigurationManager -ErrorAction Stop
        }
        $siteDrive = Get-PSDrive -Name $SiteCode -ErrorAction SilentlyContinue
        if (-not $siteDrive) {
            Write-Log -Message "Creating site drive $SiteCode for provider $ProviderMachineName" -Level 'INFO'
            New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName | Out-Null
        }
        Set-Location -Path ("{0}:\" -f $SiteCode)
        Write-Log -Message "Connected to site drive $SiteCode" -Level 'INFO'
    }

    # ══════════════════════════════════════════════════════════════════
    #  AUDIT mode (read-only via AdminService — no console module needed)
    # ══════════════════════════════════════════════════════════════════
    function Invoke-AuditList {
        [CmdletBinding()]
        param()
        $baseUrl = $null
        if ($script:config -and $script:config.ContainsKey('AdminService')) {
            $baseUrl = $script:config.AdminService.BaseUrl
        }
        if (-not $baseUrl) { $baseUrl = "https://$ProviderMachineName/AdminService" }
        $baseUrl = $baseUrl.TrimEnd('/')

        $fieldPkg = if ($script:config) { $script:config.MetadataFields.PackageProgram } else { 'Comment' }
        $fieldScr = if ($script:config) { $script:config.MetadataFields.Script }         else { 'Comment' }

        function Get-AS { param($q) (Invoke-RestMethod -Uri "$baseUrl/$q" -UseDefaultCredentials).value }

        $rows = [System.Collections.Generic.List[object]]::new()
        Write-Log -Message "Auditing Goldsmith tags via AdminService ($baseUrl)" -Level 'INFO'

        # Packages
        $pkgNames = @{}
        Get-AS 'wmi/SMS_Package?$select=PackageID,Name' | ForEach-Object { $pkgNames[$_.PackageID] = $_.Name }
        foreach ($p in (Get-AS "wmi/SMS_Program?`$select=PackageID,ProgramName,$fieldPkg")) {
            foreach ($l in (($p.$fieldPkg -split "`r?`n") | Where-Object { Test-IsMetadataLine ($_.Trim()) })) {
                $pkgItem = '{0} :: {1}' -f $pkgNames[$p.PackageID], $p.ProgramName
                $rows.Add([pscustomobject]@{ Type = 'Package'; Item = $pkgItem; Metadata = $l.Trim() })
            }
        }

        # Applications
        foreach ($a in (Get-AS 'wmi/SMS_ApplicationLatest?$select=CI_ID,LocalizedDisplayName')) {
            $d = Invoke-RestMethod -Uri "$baseUrl/wmi/SMS_Application($($a.CI_ID))?`$select=SDMPackageXML" -UseDefaultCredentials
            if ([string]::IsNullOrWhiteSpace($d.SDMPackageXML)) { continue }
            [xml]$x = $d.SDMPackageXML
            $ns = New-Object System.Xml.XmlNamespaceManager($x.NameTable)
            $ns.AddNamespace('am', 'http://schemas.microsoft.com/SystemCenterConfigurationManager/2009/AppMgmtDigest')
            foreach ($dt in $x.SelectNodes('//am:DeploymentType', $ns)) {
                $desc = $dt.SelectSingleNode('am:Description', $ns)
                if (-not $desc) { continue }
                $titleNode = $dt.SelectSingleNode('am:Title', $ns)
                $title = if ($titleNode) { $titleNode.InnerText } else { '(unnamed DT)' }
                foreach ($l in (($desc.InnerText -split "`r?`n") | Where-Object { Test-IsMetadataLine ($_.Trim()) })) {
                    $appItem = '{0} :: {1}' -f $a.LocalizedDisplayName, $title
                    $rows.Add([pscustomobject]@{ Type = 'Application'; Item = $appItem; Metadata = $l.Trim() })
                }
            }
        }

        # Scripts
        foreach ($s in (Get-AS "wmi/SMS_Scripts?`$select=ScriptName,$fieldScr")) {
            foreach ($l in (($s.$fieldScr -split "`r?`n") | Where-Object { Test-IsMetadataLine ($_.Trim()) })) {
                $rows.Add([pscustomobject]@{ Type = 'Script'; Item = $s.ScriptName; Metadata = $l.Trim() })
            }
        }

        if ($rows.Count -eq 0) {
            Write-Host 'No Goldsmith tags found in SCCM.' -ForegroundColor Yellow
        }
        else {
            $rows | Sort-Object Type, Item | Format-Table -AutoSize
            Write-Host ("{0} metadata line(s) across {1} item(s)" -f $rows.Count, (@($rows | Select-Object -Unique Item).Count)) -ForegroundColor DarkGray
        }
    }

    # ── If audit mode, do it now and skip all the write machinery ─────────
    if ($List) {
        Invoke-AuditList
        $script:auditDone = $true
        return
    }

    Initialize-ConfigMgrContext
    Write-Log -Message "Initialised. SiteCode=$SiteCode Provider=$ProviderMachineName Log=$logPath" -Level 'INFO'
}

process {
    if ($List) { return }
    if ($null -ne $InputObject) { $pipelineItems.Add($InputObject) | Out-Null }
}

end {
    if ($List) { return }

    $results = [System.Collections.Generic.List[object]]::new()

    try {
        # ── Resolve tag tokens (prompt for any missing) ───────────────────
        if (Test-IsBlank $Target) { $Target = Read-ChoiceValue -Prompt 'Target' -DefaultValue 'PX' }
        if (Test-IsBlank $Ring)   { $Ring   = Read-ChoiceValue -Prompt 'Ring'   -DefaultValue 'CORE' }
        if (Test-IsBlank $Order)  { $Order  = Read-OrderValue  -DefaultValue '00' }

        # Reboot/Pause: ValidateSet guards the PARAMETER path; the -notin
        # throws guard the INTERACTIVE path (Read-ChoiceValue bypasses
        # ValidateSet). Both are needed — do not remove either.
        if (Test-IsBlank $Reboot) { $Reboot = Read-ChoiceValue -Prompt 'Reboot (NR,RB,RA)' -DefaultValue 'NR' }
        if ($Reboot -notin @('NR', 'RB', 'RA')) { throw 'Reboot must be NR, RB, or RA.' }
        if (Test-IsBlank $Pause)  { $Pause  = Read-ChoiceValue -Prompt 'Pause (NP,PB,PA)' -DefaultValue 'NP' }
        if ($Pause -notin @('NP', 'PB', 'PA')) { throw 'Pause must be NP, PB, or PA.' }

        if (-not $PSBoundParameters.ContainsKey('OverrideValue')) {
            $enteredOverride = Read-ChoiceValue -Prompt 'OverrideValue (optional)' -DefaultValue ''
            if (-not (Test-IsBlank $enteredOverride)) { $OverrideValue = $enteredOverride }
        }

        $newMetadataLine = New-MetadataLine -Target $Target -Ring $Ring -Order $Order -Reboot $Reboot -Pause $Pause -OverrideValue $OverrideValue
        Write-Log -Message "Metadata line: $newMetadataLine" -Level 'INFO'

        # ── Gather target objects: pipeline first, else interactive ───────
        $targetObjects = @()
        if ($pipelineItems.Count -gt 0) {
            $targetObjects = @($pipelineItems)
            Write-Log -Message "Using $($targetObjects.Count) pipeline item(s)." -Level 'INFO'
        }
        else {
            if (Test-IsBlank $ItemType) {
                $ItemType = Read-ChoiceValue -Prompt 'ItemType (Application, Package, Script)' -DefaultValue 'Application'
            }
            if ($ItemType -notin @('Application', 'Package', 'Script')) {
                throw 'ItemType must be Application, Package, or Script.'
            }
            $targetObjects = @(Get-InteractiveTargets -ItemType $ItemType)
            Write-Log -Message "Interactive selection returned $($targetObjects.Count) item(s)." -Level 'INFO'
        }

        if (-not $targetObjects -or $targetObjects.Count -eq 0) {
            Write-Log -Message 'No items selected. Nothing to do.' -Level 'WARN'
            return
        }

        # ── Apply to each object ──────────────────────────────────────────
        foreach ($targetObject in $targetObjects) {
            $resolvedType = Resolve-InputType -Object $targetObject
            $identity    = ''
            $currentText = ''
            $setAction   = $null

            switch ($resolvedType) {
                'DeploymentType' {
                    $dtIdentity  = Get-DeploymentTypeIdentity -DeploymentType $targetObject
                    $identity    = "Application=[$($dtIdentity.ApplicationName)] DeploymentType=[$($dtIdentity.DeploymentTypeName)]"
                    $currentText = Get-DeploymentTypeComment -DeploymentType $targetObject
                    $setAction   = { param($textToSet) Set-DeploymentTypeComment -DeploymentType $targetObject -CommentText $textToSet }
                }
                'Program' {
                    $packageName = if ($targetObject.PSObject.Properties.Name -contains 'PackageName') { $targetObject.PackageName } else { '' }
                    $programName = if ($targetObject.PSObject.Properties.Name -contains 'ProgramName') { $targetObject.ProgramName } else { '' }
                    $identity    = "Package=[$packageName] Program=[$programName]"
                    $currentText = Get-ProgramComment -Program $targetObject
                    $setAction   = { param($textToSet) Set-ProgramCommentByInputObject -Program $targetObject -CommentText $textToSet }
                }
                'Script' {
                    $scriptName  = if ($targetObject.PSObject.Properties.Name -contains 'ScriptName') { $targetObject.ScriptName } else { '<unknown>' }
                    $identity    = "Script=[$scriptName]"
                    $currentText = Get-ScriptComment -ScriptObject $targetObject
                    $setAction   = { param($textToSet) Set-ScriptComment -ScriptObject $targetObject -CommentText $textToSet }
                }
                default {
                    Write-Log -Message 'Unsupported pipeline input object. Skipping item.' -Level 'WARN'
                    continue
                }
            }

            $mergeResult = Merge-MetadataText -CurrentText $currentText -NewMetadataLine $newMetadataLine `
                            -Target $Target -Ring $Ring -OverrideValue $OverrideValue -Force:$Force -RemoveOnly:$Remove

            if (-not $mergeResult.Changed) {
                $msg = if ($Remove) { "No matching tag to remove for $identity" } else { "No change made for $identity" }
                Write-Log -Message $msg -Level 'WARN'
                $results.Add([pscustomobject]@{
                    Identity = $identity; Type = $resolvedType; MetadataLine = $newMetadataLine
                    ExistingLine = $mergeResult.ExistingLine; Changed = $false
                    Action = if ($Remove) { 'NotFound' } else { 'Skipped' }
                }) | Out-Null
                continue
            }

            $processMsg = if ($Remove) { 'Remove metadata' } else { 'Update metadata' }
            if ($PSCmdlet.ShouldProcess($identity, $processMsg)) {
                & $setAction $mergeResult.UpdatedText
                Write-Log -Message "$(if ($Remove) { 'Removed' } else { 'Updated' }) metadata for $identity" -Level 'INFO'
            }

            $results.Add([pscustomobject]@{
                Identity = $identity; Type = $resolvedType; MetadataLine = $newMetadataLine
                ExistingLine = $mergeResult.ExistingLine; Changed = $true
                Action = if ($Remove) { 'Removed' } else { 'Updated' }
            }) | Out-Null

            if ($AutoIncrementOrder -and -not $Remove) {
                $Order = Step-OrderValue -CurrentOrder $Order
                $newMetadataLine = New-MetadataLine -Target $Target -Ring $Ring -Order $Order -Reboot $Reboot -Pause $Pause -OverrideValue $OverrideValue
                Write-Log -Message "Next order value auto-incremented to $Order" -Level 'INFO'
            }
        }

        $results.ToArray()
    }
    catch {
        Write-Log -Message $_.Exception.Message -Level 'ERROR'
        throw
    }
    finally {
        Write-Log -Message 'Completed.' -Level 'INFO'
    }
}
