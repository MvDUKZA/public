<#
.SYNOPSIS
    Start-of-day credential setup for the golden image pipeline.

.DESCRIPTION
    Prompts for every credential the pipeline needs and sets them as
    PROCESS-scoped environment variables in the current PowerShell
    session. Run it once each day (passwords rotate daily).

    Security model:
      • Nothing is EVER written to disk — no files, no registry,
        no user-scope environment variables.
      • Input uses Get-Credential / SecureString prompts, so passwords
        are never echoed to the console or the command history.
      • Plain-text conversion happens at the last possible moment
        (Packer can only read plain environment variables) and the
        interim BSTR memory is zeroed immediately after.
      • Everything vanishes when this console window closes.

    Credentials collected:
      1. vCenter          — YOUR account (audit trail shows who built)
      2. SCCM content share — the read-only service account
                              (the only credential that enters build VMs)
      3. Build VM admin   — local Administrator password baked into
                            autounattend.xml

    SCCM AdminService needs no prompt — it uses your Windows logon.

.PARAMETER Validate
    After collecting credentials, test each one: AdminService reachability
    (as you), content share access (as the service account), and vCenter
    TCP reachability. Fails loudly now rather than 40 minutes into a build.

.EXAMPLE
    .\Initialize-BuildSession.ps1 -Validate

.NOTES
    Must be run IN the console you will build from — environment
    variables are per-process. If you open a new window, run it again.
#>
[CmdletBinding()]
param(
    [switch]$Validate,
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config\build-config.psd1')
)

#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$config = Import-PowerShellDataFile -Path $ConfigPath

function ConvertFrom-SecureStringPlain {
    <#  SecureString → plain text with immediate zeroing of the interim
        unmanaged buffer. Needed because Packer reads plain env vars.  #>
    param([Parameter(Mandatory)][securestring]$Secure)
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try     { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

Write-Host ''
Write-Host '═══ Build Session Setup ══════════════════════════════════════' -ForegroundColor Cyan
Write-Host '  Credentials live in THIS console only and vanish when it'
Write-Host '  closes. Nothing is written to disk. Run again tomorrow.'
Write-Host ''
Write-Host "  SCCM AdminService: no prompt needed — runs as $env:USERDOMAIN\$env:USERNAME" -ForegroundColor DarkGray
Write-Host ''

# ── 1. vCenter — the builder's own account ────────────────────────────
Write-Host '1/3  vCenter credentials (YOUR account — the template audit' -ForegroundColor White
Write-Host '     trail in vSphere will show your name)' -ForegroundColor White
$vc = Get-Credential -Message "vCenter: $($config.VSphere.Server)" `
                     -UserName "$env:USERNAME@vsphere.local"
if (-not $vc) { throw 'Cancelled.' }

# ── 2. Content share — the read-only service account ─────────────────
Write-Host ''
Write-Host '2/3  SCCM content share service account (read-only; the only' -ForegroundColor White
Write-Host '     credential that travels into build VMs)' -ForegroundColor White
$share = Get-Credential -Message 'Content share service account (e.g. CONTOSO\svc-packer-read)'
if (-not $share) { throw 'Cancelled.' }

# ── 3. Build VM local Administrator ───────────────────────────────────
Write-Host ''
Write-Host '3/3  Build VM local Administrator password (must match the' -ForegroundColor White
Write-Host '     value in autounattend\autounattend.xml)' -ForegroundColor White
$winrmPw = Read-Host -Prompt 'Build VM Administrator password' -AsSecureString
if ($winrmPw.Length -eq 0) { throw 'Cancelled — empty password.' }

# ── Set process-scoped environment variables ──────────────────────────
$env:PKR_VAR_vcenter_username       = $vc.UserName
$env:PKR_VAR_vcenter_password       = ConvertFrom-SecureStringPlain $vc.Password
$env:PKR_VAR_content_share_username = $share.UserName
$env:PKR_VAR_content_share_password = ConvertFrom-SecureStringPlain $share.Password
$env:PKR_VAR_winrm_password         = ConvertFrom-SecureStringPlain $winrmPw
# Same share credential, names used by the generated wrapper scripts:
$env:PKR_SCCM_SHARE_USER            = $env:PKR_VAR_content_share_username
$env:PKR_SCCM_SHARE_PASS            = $env:PKR_VAR_content_share_password

Write-Host ''
Write-Host 'Session variables set:' -ForegroundColor Green
Write-Host "  vCenter user : $($vc.UserName)"
Write-Host "  Share user   : $($share.UserName)"
Write-Host '  Passwords    : held in this process only'

# ── Optional validation ───────────────────────────────────────────────
if ($Validate) {
    Write-Host ''
    Write-Host '── Validating ────────────────────────────────────────────────' -ForegroundColor White
    $failed = $false

    # AdminService as the logged-on user
    try {
        $uri = '{0}/wmi/SMS_Site?$select=SiteCode' -f $config.AdminService.BaseUrl.TrimEnd('/')
        $site = Invoke-RestMethod -Uri $uri -UseDefaultCredentials -TimeoutSec 15
        $code = ($site.value | Select-Object -First 1).SiteCode
        Write-Host "  [OK]   AdminService reachable (site $code) as $env:USERNAME" -ForegroundColor Green
    } catch {
        Write-Host "  [FAIL] AdminService: $($_.Exception.Message)" -ForegroundColor Red
        $failed = $true
    }

    # Content share as the service account
    try {
        # Probe the share root that content paths live under
        $probeRoot = ([uri]$config.OSLibrary.SharePath).Host
        $null = New-PSDrive -Name PKRPROBE -PSProvider FileSystem `
                    -Root $config.OSLibrary.SharePath -Credential $share
        Remove-PSDrive -Name PKRPROBE -Force
        Write-Host "  [OK]   Share access as $($share.UserName)" -ForegroundColor Green
    } catch {
        Write-Host "  [FAIL] Share access as $($share.UserName): $($_.Exception.Message)" -ForegroundColor Red
        $failed = $true
    }

    # vCenter reachability (TCP 443 — credential proof happens at build)
    try {
        $tcp = Test-NetConnection -ComputerName $config.VSphere.Server -Port 443 `
                 -WarningAction SilentlyContinue
        if ($tcp.TcpTestSucceeded) {
            Write-Host "  [OK]   vCenter $($config.VSphere.Server) reachable on 443" -ForegroundColor Green
        } else { throw 'TCP 443 unreachable' }
    } catch {
        Write-Host "  [FAIL] vCenter: $($_.Exception.Message)" -ForegroundColor Red
        $failed = $true
    }

    if ($failed) {
        Write-Warning 'One or more checks failed — fix before building.'
    }
}

Write-Host ''
Write-Host 'Ready. Typical next steps:' -ForegroundColor Cyan
Write-Host '  .\Invoke-PackerGenerator.ps1 -OSFolder <folder> -Target PV -DryRun'
Write-Host '  .\Start-PackerBuild.ps1      -OSFolder <folder> -Target PV'
