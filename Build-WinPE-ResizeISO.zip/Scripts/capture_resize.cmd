@echo off
setlocal enabledelayedexpansion

echo [1] Preparing scratch disk (Disk 1)...
diskpart /s scripts\scratch_prep.txt
if errorlevel 1 exit /b 1

echo [2] Assigning source letters on Disk 0...
diskpart /s scripts\capture_disk.txt
if errorlevel 1 exit /b 1

echo [3] Capturing SYSTEM (part 2)...
dism /Capture-Image ^
    /ImageFile:T:\System.wim ^
    /CaptureDir:S:\ ^
    /Name:"System" ^
    /ScratchDir:T:\
if errorlevel 1 echo ERROR capturing System & exit /b 1

echo [4] Capturing OS (part 1)...
dism /Capture-Image ^
    /ImageFile:T:\OS.wim ^
    /CaptureDir:O:\ ^
    /Name:"Windows" ^
    /ScratchDir:T:\
if errorlevel 1 echo ERROR capturing OS & exit /b 1

echo [5] Restoring Disk 0 layout...
diskpart /s scripts\restore_disk.txt
if errorlevel 1 exit /b 1

echo [6] Applying SYSTEM image...
dism /Apply-Image ^
    /ImageFile:T:\System.wim ^
    /Index:1 ^
    /ApplyDir:S:\
if errorlevel 1 echo ERROR applying System & exit /b 1

echo [7] Applying OS image...
dism /Apply-Image ^
    /ImageFile:T:\OS.wim ^
    /Index:1 ^
    /ApplyDir:O:\
if errorlevel 1 echo ERROR applying OS & exit /b 1

echo [8] Rebuilding UEFI bootloader...
bcdboot O:\Windows /s S: /f UEFI
if errorlevel 1 echo ERROR rebuilding BCD & exit /b 1

echo [9] Done. Remove WinPE media and reboot.
endlocal
