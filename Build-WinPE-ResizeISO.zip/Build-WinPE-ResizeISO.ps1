<#
.SYNOPSIS
    Build a WinPE ISO with your drivers & resize scripts.

.DESCRIPTION
    - Requires Windows ADK + WinPE Add-on installed.
    - Hard-coded paths per your request.
    - Uses copype & MakeWinPEMedia from ADK.
#>

#region Configuration
$WinPEArch         = 'amd64' 
$WorkRoot          = 'C:\WinPE\WinPE_amd64'     # where copype will lay out files
$DriverRoot        = 'C:\WinPE\Drivers'         # your VMware (or other) *.inf driver tree
$ScriptRoot        = 'C:\WinPE\Scripts'         # contains capture_resize.cmd + diskpart .txt files
$OutputISO         = 'C:\WinPE\WinPE_Resize.iso'

$ADKWinPEPath      = "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Windows Preinstallation Environment"
$CopypeCmd         = Join-Path $ADKWinPEPath 'copype.cmd'
$MakeWinPEMediaCmd = Join-Path $ADKWinPEPath 'MakeWinPEMedia.cmd'
#endregion

# simple logger
function Log($msg){ Write-Host "[Build] $msg" }

# 1) Clean & copype
if(Test-Path $WorkRoot){ Remove-Item $WorkRoot -Recurse -Force }
Log "Creating WinPE structure..."
& $CopypeCmd $WinPEArch $WorkRoot

# 2) Mount boot.wim
$Media    = Join-Path $WorkRoot 'media'
$BootWim  = Join-Path $Media 'sources\boot.wim'
$MountDir = Join-Path $WorkRoot 'mount'

New-Item -Path $MountDir -ItemType Directory -Force | Out-Null
Log "Mounting boot.wim..."
dism /Mount-Wim /WimFile:$BootWim /Index:1 /MountDir:$MountDir

# 3) Inject drivers
Log "Adding drivers from $DriverRoot..."
dism /Image:$MountDir /Add-Driver /Driver:$DriverRoot /Recurse

# 4) Copy scripts
Log "Copying scripts from $ScriptRoot..."
Copy-Item "$ScriptRoot\*" -Destination $MountDir -Recurse -Force

# 5) Ensure startnet.cmd only runs wpeinit
$SN = Join-Path $MountDir 'Windows\System32\startnet.cmd'
Set-Content -Path $SN -Value 'wpeinit'

# 6) Unmount & commit
Log "Committing changes..."
dism /Unmount-Wim /MountDir:$MountDir /Commit

# 7) Build ISO
Log "Building ISO to $OutputISO..."
& $MakeWinPEMediaCmd /ISO $WorkRoot $OutputISO

Log "Done — ISO ready at $OutputISO"
