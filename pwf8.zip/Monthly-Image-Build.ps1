Write-Output "Running monthly image build..."
.\Build-Image.ps1
