<#
.SYNOPSIS
    Automates the monthly Windows image build with Packer.
#>
param (
    [string]$RepoPath  = "C:\Packer\WindowsImageBuild",
    [string]$LogArchive = "C:\Packer\BuildLogs"
)
function Write-Log {
    param([string]$Message)
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    Write-Output "$timestamp [INFO] - $Message"
}
Write-Log "Starting monthly build script..."
.\Build-Image.ps1
