param (
    [string]$Template = "windows-vsphere.pkr.hcl",
    [string]$LogFile = ".\packer_build_$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss').log"
)
$WinPassword = Read-Host -AsSecureString "Enter Windows Administrator Password"
$SmbPassword = Read-Host -AsSecureString "Enter SMB Share Password"
$WinPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($WinPassword))
$SmbPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SmbPassword))
& packer build -var "win_password=$WinPasswordPlain" -var "smb_password=$SmbPasswordPlain" $Template | Tee-Object -FilePath $LogFile
