Write-Output "Installing core apps..."
# Example: winget install --id Google.Chrome --silent
