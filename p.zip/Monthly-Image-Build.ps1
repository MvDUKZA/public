<#
.SYNOPSIS
    Automates the monthly Windows image build with Packer.

.DESCRIPTION
    1. Prompts for Windows and SMB passwords.
    2. Pulls the latest Packer repository.
    3. Executes Build-Image.ps1 to build the vSphere template.
    4. Archives logs with a timestamp for compliance tracking.
#>

param (
    [string]$RepoPath  = "C:\Packer\WindowsImageBuild",
    [string]$LogArchive = "C:\Packer\BuildLogs"
)

function Write-Log {
    param([string]$Message, [ValidateSet("INFO","WARN","ERROR")][string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    Write-Output "$timestamp [$Level] - $Message"
}

try {
    if (!(Test-Path $RepoPath)) {
        Write-Log "Repository path $RepoPath does not exist. Cloning fresh repo..." "WARN"
        git clone https://github.com/your-org/packer-windows.git $RepoPath
    } else {
        Write-Log "Pulling latest updates from GitHub..."
        Push-Location $RepoPath
        git pull origin main
        Pop-Location
    }

    if (!(Test-Path $LogArchive)) {
        New-Item -Path $LogArchive -ItemType Directory | Out-Null
    }

    $WinPassword = Read-Host -AsSecureString "Enter Windows Administrator Password"
    $SmbPassword = Read-Host -AsSecureString "Enter SMB Share Password"

    $WinPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($WinPassword))
    $SmbPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SmbPassword))

    $Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $BuildLog = "$RepoPath\packer_build_$Timestamp.log"

    Write-Log "Starting Packer build..."
    Push-Location $RepoPath
    & .\Build-Image.ps1 -Template "windows-vsphere.pkr.hcl" -LogFile $BuildLog `
        -ErrorAction Stop `
        | Tee-Object -FilePath $BuildLog
    Pop-Location

    $ArchivePath = Join-Path $LogArchive "BuildLogs_$Timestamp"
    New-Item -Path $ArchivePath -ItemType Directory | Out-Null
    Move-Item "$RepoPath\packer_build_*.log" $ArchivePath -Force

    Write-Log "Build completed. Logs archived to $ArchivePath"
} catch {
    Write-Log "Error during monthly build: $($_.Exception.Message)" "ERROR"
    exit 1
}
