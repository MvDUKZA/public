param (
    [string]$SMBPath = "\\SERVER\Software",
    [string]$SMBPassword,
    [string]$LogFile = "C:\Windows\Temp\CoreApps_$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss').log"
)

function Write-Log {
    param ([string]$Message, [ValidateSet("INFO","WARN","ERROR")][string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "$timestamp [$Level] - $Message"
    Write-Output $logEntry
    Add-Content -Path $LogFile -Value $logEntry
}

try {
    Write-Log "Mapping SMB share $SMBPath"

    $securePassword = ConvertTo-SecureString $SMBPassword -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential("DOMAIN\PackerUser", $securePassword)

    New-PSDrive -Name "S" -PSProvider FileSystem -Root $SMBPath -Credential $credential -Persist -ErrorAction Stop
    Write-Log "SMB share mapped to S:"

    $apps = @(
        @{ Name = "Google Chrome"; Path = "S:\GoogleChromeStandaloneEnterprise64.msi"; Args = "/qn /norestart" },
        @{ Name = "Notepad++"; Path = "S:\npp.8.6.Installer.x64.exe"; Args = "/S" },
        @{ Name = "7-Zip"; Path = "S:\7z2301-x64.msi"; Args = "/qn /norestart" }
    )

    foreach ($app in $apps) {
        if (Test-Path $app.Path) {
            Write-Log "Installing $($app.Name) from $($app.Path)"
            Start-Process -FilePath $app.Path -ArgumentList $app.Args -Wait
            Write-Log "$($app.Name) installed successfully."
        } else {
            Write-Log "Installer for $($app.Name) not found." "WARN"
        }
    }
} catch {
    Write-Log "Error: $($_.Exception.Message)" "ERROR"
    exit 1
}
