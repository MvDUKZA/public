param (
    [string]$LogFile = "C:\Windows\Temp\WSUS_UpdateLog_$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss').log"
)

function Write-Log {
    param ([string]$Message, [ValidateSet("INFO","WARN","ERROR")][string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "$timestamp [$Level] - $Message"
    Write-Output $logEntry
    Add-Content -Path $LogFile -Value $logEntry
}

try {
    Write-Log "Starting WSUS update process..."
    $updateSession = New-Object -ComObject Microsoft.Update.Session
    $updateSearcher = $updateSession.CreateUpdateSearcher()

    Write-Log "Searching for available updates..."
    $searchResult = $updateSearcher.Search("IsInstalled=0 and Type='Software' and IsHidden=0")

    if ($searchResult.Updates.Count -eq 0) {
        Write-Log "No updates found."
        exit 0
    }

    $updatesToInstall = New-Object -ComObject Microsoft.Update.UpdateColl
    foreach ($update in $searchResult.Updates) {
        Write-Log "Found update: $($update.Title)"
        $updatesToInstall.Add($update) | Out-Null
    }

    Write-Log "Downloading updates..."
    $downloader = $updateSession.CreateUpdateDownloader()
    $downloader.Updates = $updatesToInstall
    $downloadResult = $downloader.Download()
    if ($downloadResult.ResultCode -ne 2) {
        Write-Log "Error downloading updates. Code: $($downloadResult.ResultCode)" "ERROR"
        exit 1
    }

    Write-Log "Installing updates..."
    $installer = $updateSession.CreateUpdateInstaller()
    $installer.Updates = $updatesToInstall
    $installResult = $installer.Install()

    for ($i = 0; $i -lt $updatesToInstall.Count; $i++) {
        $status = $installResult.GetUpdateResult($i).ResultCode
        Write-Log "Update: $($updatesToInstall.Item($i).Title) - Result: $status"
    }

    if ($installResult.RebootRequired) {
        Write-Log "Reboot required. Restarting..."
        Restart-Computer -Force
    }
} catch {
    Write-Log "Error: $($_.Exception.Message)" "ERROR"
    exit 1
}
