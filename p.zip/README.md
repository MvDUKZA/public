# Windows Packer Build for vSphere (UK English)

This repository contains a Packer template and scripts to build a **Windows 11 Golden Image** on **VMware vSphere ESXi 8.1**, following VMware best practices. It automates Windows installation, WSUS updates, and core software installations from an SMB share.

---

## **Folder Structure**
```
packer-windows/
├─ Build-Image.ps1                # Wrapper script for one-off builds
├─ Monthly-Image-Build.ps1        # Script for scheduled monthly builds
├─ windows-vsphere.pkr.hcl        # Packer template for vSphere
├─ autounattend/
│  └─ autounattend.xml            # Unattended Windows setup (UK English)
└─ scripts/
   ├─ Install-WSUSUpdates.ps1     # WSUS update installer with logging
   └─ install-core-apps.ps1       # Installs apps from SMB share
```

---

## **1. Prerequisites**
- **VMware vSphere 8.1** and a valid account.
- **Packer** installed on your build machine.
- **Git** installed (for pulling the latest repo).
- **Access to an SMB share** (e.g., `\\SERVER\Software`) with your application installers.
- **Windows ISO** stored in a vSphere datastore.
- **PowerShell 5+**.

---

## **2. Running a One-Off Build**
1. Open PowerShell as Administrator.
2. Navigate to the repository root:
   ```powershell
   cd C:\Packer\WindowsImageBuild
   ```
3. Run the build script:
   ```powershell
   .\Build-Image.ps1
   ```
4. The script will prompt for:
   - **Windows Administrator password** (for WinRM).
   - **SMB Share password** (for accessing core apps).

5. Packer will:
   - Deploy a VM from ISO.
   - Apply WSUS updates.
   - Install core applications from the SMB share.
   - Run `sysprep` and power down the image.

6. Logs are saved in:
   ```
   packer_build_<timestamp>.log
   ```

---

## **3. Setting Up Monthly Builds**
Use `Monthly-Image-Build.ps1` to automate recurring builds:

```powershell
.\Monthly-Image-Build.ps1
```

### **Scheduling**
- Open **Task Scheduler**.
- Create a new task:
  - **Trigger:** Monthly on your chosen day.
  - **Action:**  
    ```
    powershell.exe -ExecutionPolicy Bypass -File "C:\Packer\WindowsImageBuild\Monthly-Image-Build.ps1"
    ```
  - Enable **"Run whether user is logged on or not"**.
  - Enable **"Run with highest privileges"**.

Logs are archived to:
```
C:\Packer\BuildLogs\BuildLogs_<timestamp>
```

---

## **4. Adding New Applications**
1. Copy your installers (MSI/EXE) to the SMB share (`\\SERVER\Software`).
2. Edit `scripts/install-core-apps.ps1`:
   ```powershell
   $apps = @(
       @{ Name = "Google Chrome"; Path = "S:\GoogleChromeStandaloneEnterprise64.msi"; Args = "/qn /norestart" },
       @{ Name = "Notepad++"; Path = "S:\npp.8.6.Installer.x64.exe"; Args = "/S" },
       @{ Name = "7-Zip"; Path = "S:\7z2301-x64.msi"; Args = "/qn /norestart" },
       @{ Name = "YourApp"; Path = "S:\YourAppInstaller.exe"; Args = "/silent" }
   )
   ```

---

## **5. WSUS Updates**
- The `Install-WSUSUpdates.ps1` script:
  - Checks for WSUS-approved updates.
  - Logs all updates installed (`C:\Windows\Temp\WSUS_UpdateLog_<timestamp>.log`).
  - Restarts the machine automatically if required.

---

## **6. Customizing Unattended Windows Setup**
- The `autounattend/autounattend.xml` file:
  - Configured for **UK English (en-GB)**.
  - Set your own Windows product key, language, and regional settings here if needed.

---

## **7. Build Commands**
Validate and build manually (optional):
```powershell
packer init .
packer validate windows-vsphere.pkr.hcl
packer build -var "win_password=<password>" -var "smb_password=<password>" windows-vsphere.pkr.hcl
```

---

## **8. Support**
- Ensure Packer and plugins are up to date:
  ```powershell
  packer plugins install github.com/hashicorp/vsphere
  ```
- For troubleshooting, check logs in:
  - `packer_build_<timestamp>.log`
  - `C:\Windows\Temp\WSUS_UpdateLog_<timestamp>.log`
  - `C:\Windows\Temp\CoreApps_<timestamp>.log`
